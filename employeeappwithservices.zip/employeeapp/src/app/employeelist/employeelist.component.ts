import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { Employee } from "../employee";
import { EmployeeService } from "../employee.service";

@Component({
  selector: "app-employeelist",
  templateUrl: "./employeelist.component.html",
  styleUrls: ["./employeelist.component.css"],
})
export class EmployeelistComponent implements OnInit {
  employees: Employee[];
  selectedEmployeeCountRadioButton = "All";
  constructor(
    private employeeService: EmployeeService,
    private router: Router
  ) {}

  ngOnInit() {
    this.employeeService
      .getEmployees()
      .subscribe((emp) => (this.employees = emp));
  }

  getEmployeeCount(): number {
    return this.employees.length;
  }

  deleteEmployee(empid: number) {
    // console.log(JSON.stringify());
    console.log("delete called");
    console.log(empid);
    this.employeeService
      .delete(empid)
      .subscribe((m) => this.router.navigate(["emps"]));
  }

  getMaleEmployeeCount(): number {
    return this.employees.filter((e) => e.gender.toLowerCase() === "male")
      .length;
  }

  getFemaleEmployeeCount(): number {
    return this.employees.filter((e) => e.gender.toLowerCase() === "female")
      .length;
  }

  onEmployeeCountRadioButtonChange(selectedValue: string) {
    this.selectedEmployeeCountRadioButton = selectedValue;
  }
}
