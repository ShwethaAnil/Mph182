import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-pagenotfound",
  template: ` <h1>Page is not available</h1> `,
  styles: [],
})
export class PagenotfoundComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
