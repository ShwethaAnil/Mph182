import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, throwError } from "rxjs";
import { Employee } from "./employee";
import { catchError } from "rxjs/operators";

@Injectable({
  providedIn: "root",
})
export class EmployeeService {
  employees: Employee[];

  headers = {
    headers: new HttpHeaders({
      "Content-Type": "application/json",
    }),
  };

  constructor(private httpClient: HttpClient) {}

  getEmployees(): Observable<Employee[]> {
    return this.httpClient
      .get<Employee[]>("http://localhost:8097/emp")
      .pipe(catchError(this.errorHandler));
  }

  addEmployee(employee: Employee) {
    console.log("service called");
    console.log(employee);
    return this.httpClient
      .post<Employee>(
        "http://localhost:8097/emp",
        JSON.stringify(employee),
        this.headers
      )
      .pipe(catchError(this.errorHandler));
  }

  delete(eid: number) {
    console.log("called");
    console.log(eid);
    return this.httpClient
      .delete<Employee>(`http://localhost:8097/${eid}`)
      .pipe(catchError(this.errorHandler));
  }

  getEmployeeById(eid: number): Observable<Employee> {
    // emp = new Employee();
    // emp.empid = 111;
    // emp.ename = "Aman";
    // emp.gender = "Male";
    // emp.salary = 5467887;
    // emp.dob = "12-12-2005";

    return this.httpClient
      .get<Employee>(`http://localhost:8097/emp/${eid}`)
      .pipe(catchError(this.errorHandler));
  }

  errorHandler(eror: HttpErrorResponse) {
    return throwError(eror);
  }
}
