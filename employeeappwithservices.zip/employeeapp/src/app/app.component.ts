import { Component } from "@angular/core";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  // template: `<h1>Welcome</h1>
  //   <div>Sample Code</div>`,
  styleUrls: ["./app.component.css"],
})
export class AppComponent {
  title = "employeeapp";
}

// ng serve -o
// ng serve --port= 4300
