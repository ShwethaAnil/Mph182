package com.training.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.training.pojos.Candidate;

public class CandidateServiceImpl implements CandidateService {

	static  List<Candidate> candidates=new ArrayList<Candidate>();
	static {
		candidates.add(new Candidate("Deepak", "Java", "Mangalore", 23));
		candidates.add(new Candidate("MeghaR", "C++", "Mangalore", 13));
		candidates.add(new Candidate("Jahnavi", "Java", "Pune", 23));
		candidates.add(new Candidate("Shodhan", "C", "Chennai", 10));
		candidates.add(new Candidate("SupriyaKV", "Java", "Bangalore", 3));
		candidates.add(new Candidate("Supriya", "C", "Bangalore", 2));
		candidates.add(new Candidate("Vishal", "DB", "Hyderabad", 9));
		candidates.add(new Candidate("Vijeth", "Java", "Chennai", 0));
		candidates.add(new Candidate("Prathap", "DB", "Pune", 14));
		candidates.add(new Candidate("Swathi ", "C++", "Hyderabad", 25));
		candidates.add(new Candidate("Yashaswini ", "Java", "Mumbi", 1));
		candidates.add(new Candidate("Suraj", "Java", "Bangalore", 8));
		candidates.add(new Candidate("Sowmya", "DB", "Hyderabad", 0));
		candidates.add(new Candidate("Uday", "Java", "Chennai", 0));
		candidates.add(new Candidate("Kalandar", "DB", "Pune", 22));
		candidates.add(new Candidate("Nishith", "C++", "Hyderabad", 25));
		candidates.add(new Candidate("Hemashreee", "Java", "Mumbi", 1));
		candidates.add(new Candidate("Riqa", "Java", "Bangalore", 8));
		candidates.add(new Candidate("Prem", "Java", "Mangalore", 23));
		candidates.add(new Candidate("Meghana V", "C++", "Mangalore", 13));
	}
	
	
	@Override
	public List<Candidate> getCandidates() {
		return candidates;
	}

	@Override
	public void addCandidate(Candidate candidate) {
		candidates.add(candidate);
	}

	@Override
	public Optional<Candidate> getCandidate(int index) {
		return Optional.ofNullable(candidates.get(index));
	}

}
