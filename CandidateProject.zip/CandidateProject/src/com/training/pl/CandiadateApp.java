package com.training.pl;

import java.util.Scanner;

import com.training.service.CandidateService;
import com.training.service.CandidateServiceImpl;

public class CandiadateApp {
	
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		CandidateService candidateService=new CandidateServiceImpl();
		do {
		System.out.println("1.Get List of candidate\n 2. Add Candidate "
				+ "\n 3. List of Candidates(city)"
				+ "\n 4. Sort List of Candidates based on years of experience"
				+ "\n 5. Sort Based on Cities"
				+ "\n 6. List Freshers"
				+ "\n 7. List Highest exprirenced candidate"
				+ "\n 8.candidate count per technolog "
				+ "\n 9.candidate city and skills \n 10.Exit");
		switch(sc.nextInt()) {
		case 1:
			
			break;
		case 2:
			
			break;
		case 3: System.out.println("List of  Candidates for given city");
		        
		        break;
		case 4:  System.out.println("Sort based on expeirence");
				
				break;
		case 5: System.out.println("sort based on cities");	
				
				break;
		case 6:System.out.println("List of fresher");
				
			  break;
		case 7: System.out.println("List of heighest experienced candidate");
				
		       break;
		case 8: System.out.println("candidate count per technology");
				
				break;
		case 9: System.out.println("candidate for entered city and entered skill");	
					
				break;	
		case 10:	System.out.println("Retrive a candidate by index");
			
		           break;
		case 11: System.out.println("Thank you");
				sc.close();
				System.exit(0);
		default:System.out.println("invalid option");		
		}
		}while(true);
		
	}

}
