package com.mphasis.training.pl;

import java.util.Scanner;

import com.mphasis.training.bos.ProductBo;
import com.mphasis.training.bos.ProductBoImpl;
import com.mphasis.training.pojos.Product;

public class ProductApp {

	public static void main(String[] args) {
		System.out.println("Welcome to Product App");
		Scanner sc=new Scanner(System.in);
		ProductBo productBo=new ProductBoImpl();
		do {
			System.out.println("1. Add Product \n 2. Retrive Product by index \n 3. Retive all Products \n "
					+ "4. Find the quality of a Product \n 5. Exit");
			switch(sc.nextInt()) {
			case 1:
				    System.out.println("Enter the Product details 1. pid, 2.pname 3.qty 4.cost 5.ratings");
			        Product p =new Product(sc.next(), sc.next(), sc.nextInt(), sc.nextDouble(), sc.nextDouble());
			        System.out.println("Enter the index");
			        productBo.addProduct(p, sc.nextInt());
				    break;
			case 2: System.out.println("Enter the index");
					Product product= productBo.getProductByIndex(sc.nextInt());
					System.out.println(product);
					break;
			case 3:System.out.println("List of products");
					Product[] prods=productBo.getProducts();
					for(Product p1:prods) {
						System.out.println(p1);
					}
				break;
			case 4: System.out.println("Enter the index whic you want to know the quality");
					int index=sc.nextInt();
					Product p2= productBo.getProductByIndex(index);
			      String quality = productBo.getQualityOfProduct(index);
			      System.out.println("Product name"+p2.getPname()+"  Quality of a product " +quality);
			      break;
			case 5: System.out.println("Thank you");
			        sc.close();
			        System.exit(0);
			 default: System.out.println("Invalid choice");       
			}
			
		}while(true);

	}

}
