package com.mphasis.training.bos;

import com.mphasis.training.pojos.Product;

public interface ProductBo {

	
		public Product[] getProducts();
		public Product getProductByIndex(int index);
		public void addProduct(Product p,int index);
		public String getQualityOfProduct(int index);


}
