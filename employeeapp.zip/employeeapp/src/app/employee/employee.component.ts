import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-employee",
  templateUrl: "./employee.component.html",
  styleUrls: ["./employee.component.css"],
})
export class EmployeeComponent implements OnInit {
  empid = 111;
  ename = "Aman";
  gender = "Male";
  salary = 5467887;
  dob = "12-12-2005";
  showDetails = false;

  someText = "Nida is so <b>Sweet</b>";

  constructor() {}

  ngOnInit() {}

  toggle() {
    this.showDetails = !this.showDetails;
  }
}
