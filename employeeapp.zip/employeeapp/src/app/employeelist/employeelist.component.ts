import { Component, OnInit } from "@angular/core";
import { Employee } from "../employee";

@Component({
  selector: "app-employeelist",
  templateUrl: "./employeelist.component.html",
  styleUrls: ["./employeelist.component.css"],
})
export class EmployeelistComponent implements OnInit {
  employees: Employee[];
  selectedEmployeeCountRadioButton = "All";
  constructor() {}

  ngOnInit() {
    this.employees = [
      {
        empid: 111,
        ename: "Aman",
        gender: "Male",
        salary: 567876,
        dob: "12-09-1998",
      },
      {
        empid: 112,
        ename: "Karan",
        gender: "Male",
        salary: 667876,
        dob: "2-09-1998",
      },
      {
        empid: 113,
        ename: "Vinutha",
        gender: "Female",
        salary: 867876,
        dob: "1-09-1998",
      },
      {
        empid: 114,
        ename: "Amulya",
        gender: "Female",
        salary: 967876,
        dob: "6-09-1998",
      },
      {
        empid: 115,
        ename: "Anjali",
        gender: "Female",
        salary: 8767876,
        dob: "2-09-1998",
      },
      {
        empid: 116,
        ename: "Krishna",
        gender: "Male",
        salary: 567876,
        dob: "11-09-1998",
      },
      {
        empid: 117,
        ename: "Ankita",
        gender: "Female",
        salary: 597876,
        dob: "11-09-1998",
        address: "Bangalore",
      },
    ];
  }

  getEmployeeCount(): number {
    return this.employees.length;
  }

  getMaleEmployeeCount(): number {
    return this.employees.filter((e) => e.gender.toLowerCase() === "male")
      .length;
  }

  getFemaleEmployeeCount(): number {
    return this.employees.filter((e) => e.gender.toLowerCase() === "female")
      .length;
  }

  onEmployeeCountRadioButtonChange(selectedValue: string) {
    this.selectedEmployeeCountRadioButton = selectedValue;
  }
}
