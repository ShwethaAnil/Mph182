import { RainbowDirective } from './rainbow.directive';

describe('RainbowDirective', () => {
  it('should create an instance', () => {
    const directive = new RainbowDirective();
    expect(directive).toBeTruthy();
  });
});
