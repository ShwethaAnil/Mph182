import { Component, OnInit } from "@angular/core";
import { Employee } from "../employee";

@Component({
  selector: "app-addemployee",
  templateUrl: "./addemployee.component.html",
  styleUrls: ["./addemployee.component.css"],
})
export class AddemployeeComponent implements OnInit {
  emp = new Employee();
  constructor() {}
  ngOnInit() {}
  saveEmployee() {
    console.log(JSON.stringify(this.emp));
  }
}
