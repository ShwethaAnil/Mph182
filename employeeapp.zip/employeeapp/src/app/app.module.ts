import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { EmployeeComponent } from "./employee/employee.component";
import { EmployeelistComponent } from "./employeelist/employeelist.component";
import { TitlePipe } from "./title.pipe";
import { EmployeecountComponent } from "./employeecount/employeecount.component";
import { FormsModule } from "@angular/forms";
import { AddemployeeComponent } from "./addemployee/addemployee.component";
import { PagenotfoundComponent } from "./pagenotfound/pagenotfound.component";
import { NavComponent } from './nav/nav.component';
import { RainbowDirective } from './rainbow.directive';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    EmployeelistComponent,
    TitlePipe,
    EmployeecountComponent,
    AddemployeeComponent,
    PagenotfoundComponent,
    NavComponent,
    RainbowDirective,
  ],
  imports: [BrowserModule, FormsModule, AppRoutingModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
