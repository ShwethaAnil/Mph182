package com.mphasis.training.controllers;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mphasis.training.bos.ProductBo;
import com.mphasis.training.entities.Product;
import com.mphasis.training.exceptions.BuisnessException;

@Controller
public class ProductController {
	
	@Autowired
	private ProductBo productBo;

	@RequestMapping("/home")
	public String getMethod() {
		System.out.println("Method Called");
		return "home";
	}
	//Model +View
//	@RequestMapping("/products")
//	public String getProductsMethod(Model model) throws BuisnessException {
//		List<Product> products=productBo.getProducts();
//		System.out.println("Method Called "+products);
//		model.addAttribute("products", products);
//		return "products";
//	}
	@RequestMapping(value="/login", method = RequestMethod.GET)
	public String login() {
		return "login";
	}
	
	@RequestMapping(value="/login", method = RequestMethod.POST)
	public String loginMethod(@RequestParam("uname")String name,@RequestParam("pwd")String pwd) {
		System.out.println(name+" "+pwd);
		return "redirect:/products";
	}
	
	@RequestMapping("/products")
	public ModelAndView getProductsMethod(){
		ModelAndView mv=new ModelAndView();
		mv.setViewName("products");
		try {
			List<Product> products = productBo.getProducts();
			System.out.println("Method Called "+products);
			mv.addObject("products", products);
		} catch (BuisnessException e) {
			mv.addObject("message", e.getMessage());
		}	
		return mv;
	}
	
	@RequestMapping(value="/delete/{pid}")
	public String delete(@PathVariable String pid) throws BuisnessException{
		productBo.removeProduct(pid);
		return "redirect:/products";
		
	}
	
	@RequestMapping(value="/edit/{pid}")
	public String edit(@PathVariable("pid") String pid, Model model)  {
		Product p;
		try {
			p = productBo.getProductById(pid);
			model.addAttribute("product",p);
			System.out.println("edit called "+p);
		} catch (BuisnessException | SQLException e) {
			model.addAttribute("message", e.getMessage());
		}
		
		return "addproduct";
	}
	

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	//@PostMapping("/edit")
	public String editProduct(@ModelAttribute("product") Product product) {
		try {
			System.out.println("edit post called"+product);
			productBo.editProduct(product.getPid(), product.getCost(), product.getQty());
		} catch (BuisnessException e) {
			
		}
		return "redirect:/products";
	}

	@RequestMapping(value="/add", method=RequestMethod.GET)
	public String addProductPage(Model model) {
		Product p=new Product();
		model.addAttribute("product",p);
		return "addproduct";
	}
	
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public String addProduct(@ModelAttribute("product")Product product, Model model)  {
		try {
			productBo.addProduct(product);
		} catch (BuisnessException e) {
			model.addAttribute("message", e.getMessage());
			
		}
		return "redirect:/products";
	}
	
}