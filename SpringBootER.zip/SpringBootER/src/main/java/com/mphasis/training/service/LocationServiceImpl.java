package com.mphasis.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.training.daos.LocationDao;
import com.mphasis.training.entities.Location;

@Service
public class LocationServiceImpl implements LocationService {
	@Autowired
	LocationDao LocationDao;

	public void addLocation(Location d) {
		LocationDao.save(d);
	}

	public void updateLocation(Location d) {
		LocationDao.save(d);
	}

	public void deleteLocation(int did) {
		LocationDao.deleteById(did);
	}

	public Location getLocationById(int did) {
		return LocationDao.findById(did).get();
	}

	public List<Location> getAll() {
		return (List<Location>) LocationDao.findAll();
	}
}
