package com.mphasis.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.training.daos.DepartmentDao;
import com.mphasis.training.daos.EmployeeDao;
import com.mphasis.training.dto.EmployeeTo;
import com.mphasis.training.entities.Department;
import com.mphasis.training.entities.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeDao employeeDao;

	@Autowired
	DepartmentDao departmentDao;
	
	public void addEmployee(Employee e) {
		employeeDao.save(e);

	}

	public void updateEmployee(Employee e) {
		employeeDao.save(e);		
	}

	public void deleteEmployee(int eid) {
		employeeDao.deleteById(eid);
	}

	public Employee getEmployeeById(int eid) {
		return employeeDao.findById(eid).get();
	}

	public List<Employee> getAll() {
		return (List<Employee>) employeeDao.findAll();
	}

	public List<Employee> getEmployeeByDept(int did) {
		Department d=departmentDao.findById(did).get();
		return employeeDao.findByDept(d);
	}

	public List<EmployeeTo> findByEmployees(String jname){
		return employeeDao.findByEmployees(jname);
	}

	public List<Employee> getEmployeeByName(String like) {
		return employeeDao.findByEnameLike(like);
	}

}
