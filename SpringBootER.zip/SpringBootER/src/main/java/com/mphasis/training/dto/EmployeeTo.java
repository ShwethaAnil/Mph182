package com.mphasis.training.dto;



public interface EmployeeTo {
	
	 int getEid();
	 String getEname();
	 String getDname();
	 String getLname();
	 String getJname();	
}
