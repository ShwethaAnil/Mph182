package com.mphasis.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.training.daos.JobDao;
import com.mphasis.training.entities.Job;

@Service
public class JobServiceImpl implements JobService {
	@Autowired
	JobDao JobDao;

	public void addJob(Job d) {
		JobDao.save(d);
	}

	public void updateJob(Job d) {
		JobDao.save(d);
	}

	public void deleteJob(String did) {
		JobDao.deleteById(did);
	}

	public Job getJobById(String did) {
		return JobDao.findById(did).get();
	}

	public List<Job> getAll() {
		return (List<Job>) JobDao.findAll();
	}
}
