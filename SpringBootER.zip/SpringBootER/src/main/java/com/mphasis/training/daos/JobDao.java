package com.mphasis.training.daos;



import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mphasis.training.entities.Job;

@Repository
public interface JobDao extends CrudRepository<Job, String> {
	
}
