package com.mphasis.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.training.daos.DepartmentDao;
import com.mphasis.training.entities.Department;

@Service
public class DepartmentServiceImpl implements DepartmentService {
	@Autowired
	DepartmentDao departmentDao;

	public void addDepartment(Department d) {
		departmentDao.save(d);
	}

	public void updateDepartment(Department d) {
		departmentDao.save(d);
	}

	public void deleteDepartment(int did) {
		departmentDao.deleteById(did);
	}

	public Department getDepartmentById(int did) {
		return departmentDao.findById(did).get();
	}

	public List<Department> getAll() {
		return (List<Department>) departmentDao.findAll();
	}
}
