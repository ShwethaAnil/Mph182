package com.mphasis.training.daos;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mphasis.training.dto.EmployeeTo;
import com.mphasis.training.entities.Department;
import com.mphasis.training.entities.Employee;

@Repository
public interface EmployeeDao  extends CrudRepository<Employee, Integer>{
	
	public List<Employee> findByDept(Department d);
	
	public List<Employee> findByEnameLike(String ename);
	
	
	@Query(value = "select e.eid,e.ename,j.jname,d.dname,l.lname from employee e, loc l, dept d,job j where e.dept_did=d.did and d.loc_lid=l.lid and e.job_jcode=j.jcode and j.jname=:jname", nativeQuery = true)
	public List<EmployeeTo> findByEmployees(String jname);
	
}
