package com.mphasis.training.daos;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mphasis.training.entities.Department;

@Repository
public interface DepartmentDao extends CrudRepository<Department, Integer> {
	
}
