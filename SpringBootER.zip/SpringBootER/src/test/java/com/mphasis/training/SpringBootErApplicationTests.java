package com.mphasis.training;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootErApplicationTests {

	@Test
	void contextLoads() {
	}

}
