package com.mphasis.training.bos;

import java.util.List;

import com.mphasis.training.exceptions.BuisnessException;
import com.mphasis.training.pojos.Product;

public interface ProductBo {

	
		public List<Product> getProducts()throws BuisnessException;
		public Product getProductByIndex(String pid)throws BuisnessException;
		public void addProduct(Product p) throws BuisnessException;
		public String getQualityOfProduct(String pid)throws BuisnessException;
		public void editProduct(String pid, double cost)throws BuisnessException;
		public void removeProduct(String pid)throws BuisnessException;
		public List<Product> sortByPname();
		public List<Product> sortByCost();
		public List<Product> sortByRatings();
		public List<Product> sortByQty();

}
