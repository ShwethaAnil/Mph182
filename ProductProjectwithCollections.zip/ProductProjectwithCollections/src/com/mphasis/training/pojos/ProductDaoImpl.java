package com.mphasis.training.pojos;

import java.util.ArrayList;
import java.util.List;

import com.mphasis.training.daos.ProductDao;

public class ProductDaoImpl implements ProductDao {
	List<Product> products=null;
	
	 public ProductDaoImpl() {
		products=new ArrayList<>();
		products.add(new Product("P123","Watch",456,345678,4));
		products.add(new Product("P124","Mi4",46,34678,4.4));
		products.add(new Product("P125","Vivo10",56,45678,4.3));
		products.add(new Product("P126","Oppf11",45,34578,4.4));
		products.add(new Product("P127","Mi8",476,34568,4.6));
		products.add(new Product("P128","Applei11",956,3478,4.9));
		products.add(new Product("P123","Watch",456,345678,4));
	}

	@Override
	public List<Product> retriveProducts() {
	
		return products;
	}

	@Override
	public void addProduct(Product p) {
		products.add(p);
	}

	@Override
	public void updateProduct(String pid, double cost) {
		for(Product p:products) {
			if(pid.equals(p.getPid())) {
				p.setCost(cost);
			}
		}

	}

	@Override
	public void deleteProduct(String pid) {
		// TODO Auto-generated method stub
		for(Product p:products) {
			if(pid.equals(p.getPid())) {
				products.remove(p);
			}
		}
	}

	@Override
	public Product retiveProductById(String pid) {
		Product product=null;
		for(Product p:products) {
			if(pid.equals(p.getPid())) {
				product=p;
			}
		}
		return product;
	}

}
