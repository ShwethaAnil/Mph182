package com.mphasis.training.daos;

import java.util.List;

import com.mphasis.training.pojos.Product;

public interface ProductDao {
	
	public List<Product> retriveProducts();
	public void addProduct(Product p);
	public void updateProduct(String pid, double cost);
	public void deleteProduct(String pid);
	public Product retiveProductById(String pid);
}
