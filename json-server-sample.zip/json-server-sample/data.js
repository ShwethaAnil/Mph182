module.exports = function(){
	return {
		products:[
			{id:1, name:"Flycom Lace UpShoe", category: "category 1", description:"Sneaker Shoe(category 1)", price: 12344},
      {id:2, name:"Rebook Watch", category:"category 2",  description:"Rebook Shoe(category 2)", price: 144},
      {id:3, name:" Washing Machine", category:"category 3",  description:"Sneaker Shoe(category 3)", price: 2344},
      {id:4, name:"Hp Laptop", category:"category 4",  description:"Sneaker Shoe(category 4)", price: 2344},
      {id:5, name:"FastTrack watch", category:"category 2",  description:"FastTrack watch(category 2)", price: 344},
      {id:6, name:"Flycom Lace UpShoe", category:"category 1",  description:"Sneaker Shoe(category 1)", price: 1344},
      {id:7, name:"Flycom Lace UpShoe", category:"category 3",  description:"Sneaker Shoe(category 3)", price: 12344},
      {id:8, name:"Flycom Lace UpShoe", category:"category 2",  description:"Sneaker Shoe(category 2)", price: 1144},
      {id:9, name:"Flycom Lace UpShoe", category:"category 1",  description:"Sneaker Shoe(category 1)",price:  2344},
      {id:10, name:"Flycom Lace UpShoe", category:"category 4",  description:"Sneaker Shoe(category 4)", price: 2344}
    ],
    orders:[

    ]
	}
}
