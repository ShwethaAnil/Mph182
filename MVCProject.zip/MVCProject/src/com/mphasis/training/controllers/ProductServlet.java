package com.mphasis.training.controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mphasis.training.bos.MuserBo;
import com.mphasis.training.bos.MuserBoImpl;
import com.mphasis.training.bos.ProductBo;
import com.mphasis.training.bos.ProductBoImpl;
import com.mphasis.training.exceptions.BuisnessException;
import com.mphasis.training.pojos.Muser;
import com.mphasis.training.pojos.Product;

/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("/")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ProductBo productBo = new ProductBoImpl();
	
	MuserBo muserBo=new MuserBoImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();
		// System.out.println(action+" path is ");
		try {
			switch (action) {
			case "/login":
				login(request,response);
				break;
			case "/register":
				register(request,response);
				break;
			case "/new":
				showNewForm(request, response);
				break;
			case "/insert":
				insertProduct(request, response);
				break;
			case "/edit":
				showEditForm(request, response);
				break;
			case "/update":
				updateProduct(request, response);
				break;
			case "/delete":
				deleteProduct(request, response);
				break;
			case "/adminProducts":
				adminView(request,response);
				break;
			case "/change":
				changeViewForm(request,response);
				break;
			case "/changePassword":
				changePassword(request,response);
				break;
			case "/logout":
				logout(request,response);
				break;
			case "/plist":
				listProducts(request, response);
				break;
			default:
				pageNotFound(request,response);
				break;
				
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	

	private void pageNotFound(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setAttribute("lmessage", "Requested Page is Not Available");
		RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
		rd.forward(request, response);
	}



	private void changePassword(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(false);
		Muser m=(Muser) session.getAttribute("suser");
		System.out.println(m);
		String message=null;
		try {
			muserBo.changePassword(request.getParameter("pass"), m.getUserid());
			message = "Password Changed sucessfully";
		} catch (BuisnessException e) {
			message= e.getMessage();
		}
		
		request.setAttribute("message", message);
		RequestDispatcher rd=request.getRequestDispatcher("change");
		rd.forward(request, response);
	}

	private void changeViewForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd=request.getRequestDispatcher("changepassword.jsp");
		rd.forward(request, response);
	}

	private void logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(false);
		session.removeAttribute("suser");
		session.invalidate();
		RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
		rd.forward(request, response);
		
	}

	private void adminView(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			List<Product> products = productBo.getProducts();
			ServletContext context = request.getServletContext();
			context.setAttribute("products", products);
		} catch (BuisnessException e) {
			request.setAttribute("message", e.getMessage());
		}
		RequestDispatcher rd = request.getRequestDispatcher("adminproducts.jsp");
		rd.forward(request, response);
		
	}

	private void register(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Muser muser=new Muser();
		muser.setUname(request.getParameter("uname"));
		muser.setPass(request.getParameter("pass"));
		muser.setGender(request.getParameter("gen"));
		muser.setRole("Customer");
		
		try {
			muserBo.registerUser(muser);
			request.setAttribute("emessage","Registered Succesfully. Please login");
		} catch (BuisnessException e) {
			request.setAttribute("emessage", e.getMessage());
			
		}
		RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
		rd.include(request, response);
	}

	private void login(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String name = request.getParameter("uname");
		String pass=request.getParameter("pass");
		
		try {
			Muser muser=muserBo.login(name, pass);
			HttpSession session=request.getSession();
			session.setAttribute("suser", muser);
			if(muser.getRole().equalsIgnoreCase("admin")) {
				response.sendRedirect("adminProducts");	
			}else {
				response.sendRedirect("plist");
			}
		} catch (BuisnessException| NullPointerException e) {
			request.setAttribute("message", e.getMessage());
			RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
			rd.include(request, response);
		}
		
		
	}

	private void deleteProduct(HttpServletRequest request, HttpServletResponse response) throws IOException {
		try {
			productBo.removeProduct(request.getParameter("pid"));
		} catch (BuisnessException e) {
			ServletContext context=request.getServletContext();
			context.setAttribute("message", e.getMessage());
			
		}
		response.sendRedirect("adminProducts");

	}

	private void updateProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		double cost = Double.parseDouble(request.getParameter("cost"));
		String pid= request.getParameter("pid");
		int qty=Integer.parseInt(request.getParameter("qty"));
		try {
			productBo.editProduct(pid, cost, qty);
		} catch (BuisnessException e) {
			request.setAttribute("message", e.getMessage());
			RequestDispatcher rd = request.getRequestDispatcher("addproduct.jsp");
			rd.forward(request, response);
		}

	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		try {
			Product p=productBo.getProductById(request.getParameter("pid"));
			//ServletContext context=request.getServletContext();
			request.setAttribute("product",p);
			
		
		} catch (BuisnessException e) {
			request.setAttribute("message", e.getMessage());
			
		} catch (SQLException e) {
			request.setAttribute("message", e.getMessage());
			
		}
		
		RequestDispatcher rd = request.getRequestDispatcher("addproduct.jsp");
		rd.forward(request, response);

	}

	private void insertProduct(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		Product p = new Product();
		p.setPid(request.getParameter("pid"));
		p.setPname(request.getParameter("pname"));
		p.setQty(Integer.parseInt(request.getParameter("qty")));
		p.setCost(Double.parseDouble(request.getParameter("cost")));
		p.setRatings(Double.parseDouble(request.getParameter("ratings")));

		System.out.println("Insert called");
		try {
			productBo.addProduct(p);
			System.out.println("product added");
			response.sendRedirect("adminProducts");
		} catch (BuisnessException | SQLException  e) {
			
			request.setAttribute("message", e.getMessage());
			//request.setAttribute("product", p);
			RequestDispatcher rd = request.getRequestDispatcher("addproduct.jsp");
			rd.forward(request, response);
			
		}

	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("addproduct.jsp");
		rd.forward(request, response);
	}

	private void listProducts(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			List<Product> products = productBo.getProducts();
			ServletContext context = request.getServletContext();
			context.setAttribute("products", products);
		} catch (BuisnessException e) {
			request.setAttribute("message", e.getMessage());
		}
		RequestDispatcher rd = request.getRequestDispatcher("products.jsp");
		rd.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
