package com.mphasis.training.pojos;

public class Muser {
private int	userid ;
private String	uname ;
private String	pass ;
private String	gender;
private String	role ;

public Muser() {
	
}

public int getUserid() {
	return userid;
}

public void setUserid(int userid) {
	this.userid = userid;
}

public String getUname() {
	return uname;
}

public void setUname(String uname) {
	this.uname = uname;
}

public String getPass() {
	return pass;
}

public void setPass(String pass) {
	this.pass = pass;
}

public String getGender() {
	return gender;
}

public void setGender(String gender) {
	this.gender = gender;
}

public String getRole() {
	return role;
}

public void setRole(String role) {
	this.role = role;
}

@Override
public String toString() {
	return "Muser [userid=" + userid + ", uname=" + uname + ", pass=" + pass + ", gender=" + gender + ", role=" + role
			+ "]";
}

public Muser(int userid, String uname, String pass, String gender, String role) {
	super();
	this.userid = userid;
	this.uname = uname;
	this.pass = pass;
	this.gender = gender;
	this.role = role;
}


}
