package com.mphasis.training.bos;

import java.util.List;

import com.mphasis.training.daos.MuserDao;
import com.mphasis.training.daos.MuserDaoImpl;
import com.mphasis.training.exceptions.BuisnessException;
import com.mphasis.training.pojos.Muser;

public class MuserBoImpl implements MuserBo {
	MuserDao muserDao=null;
	public MuserBoImpl() {
		muserDao=new MuserDaoImpl();
	}
	

	@Override
	public int registerUser(Muser u)throws BuisnessException {
		int i=0;
		
			if(u.getUname().matches("[a-zA-Z]{3,15}")) {
				if(u.getPass().matches("([A-Za-z0-9]){3,9}")) {
				i=	muserDao.insertUser(u);
				}else
				{
					throw new BuisnessException("Pass is invalid");
				}
			}else
			{
				throw new BuisnessException("user name must be alphabet");
			}
			
		
		return i;
	}

	@Override
	public Muser login(String name, String pass) throws BuisnessException {
		//Muser m = new Muser();
		Muser m =muserDao.retriveUserByNameAndPassword(name, pass);
		if(m != null) {
			return m;
		}else {
			throw new BuisnessException("User is not present");
		}
	}

	@Override
	public int changePassword(String newPass, int userid) throws BuisnessException {
		int i=0;
		if(newPass.matches("([A-Za-z0-9]){3,9}")) {
			 i=muserDao.updatePassword(newPass, userid);
		}else {
			throw new BuisnessException("Password should be with 3 to 9 letters");
		}
		return i;
	}

	@Override
	public List<Muser> getAllUsers() throws BuisnessException {
		List<Muser> muser=muserDao.retriveAll();
		if(muser.isEmpty())
			throw new BuisnessException("No Users");
		return muser;
	}

}
