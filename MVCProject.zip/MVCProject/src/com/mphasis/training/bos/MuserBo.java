package com.mphasis.training.bos;

import java.util.List;

import com.mphasis.training.exceptions.BuisnessException;
import com.mphasis.training.pojos.Muser;

public interface MuserBo {
	public int registerUser(Muser muser)throws BuisnessException;
	public Muser login(String name,String pass)throws BuisnessException;
	public int changePassword(String newPass,int userid)throws BuisnessException;
	public List<Muser> getAllUsers()throws BuisnessException;
}
