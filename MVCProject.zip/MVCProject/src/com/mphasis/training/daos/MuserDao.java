package com.mphasis.training.daos;

import java.util.List;

import com.mphasis.training.pojos.Muser;

public interface MuserDao {
	public int insertUser(Muser muser);
	public Muser retriveUserByNameAndPassword(String name,String pass);
	public int updatePassword(String newPass,int userid);
	public List<Muser> retriveAll();
}
