package com.mphasis.training.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.training.pojos.Muser;
import com.mphasis.training.util.DbUtil;

public class MuserDaoImpl implements MuserDao {

	Connection con=null;
	public MuserDaoImpl() {
		con=DbUtil.openConnection();
	}
	
	@Override
	public int insertUser(Muser m) {
		int i=0;
		try {
			String sql="insert into muser values(user_seq.nextval,?,?,?,?)";
			PreparedStatement pst=con.prepareStatement(sql);
			//pst.setInt(1, m.getUserid());
			pst.setString(1, m.getUname());
			pst.setString(2, m.getPass());
			pst.setString(3, m.getGender());
			pst.setString(4, m.getRole());
			i=pst.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return i;
		
	}

	@Override
	public Muser retriveUserByNameAndPassword(String name, String pass) {
		Muser u = new Muser();
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String query="select * from muser where uname=? and pass=?";
			 pst=con.prepareStatement(query);
			 pst.setString(1, name);
			 pst.setString(2, pass);
			 rs=pst.executeQuery();
			if(rs.next()) {
				u.setUserid(rs.getInt("userid"));
				u.setUname(rs.getString("uname"));
				u.setPass(rs.getString("pass"));
				u.setRole(rs.getString("role"));
				u.setGender(rs.getString("gender"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				pst.close();
			} catch (SQLException e) {
			
				e.printStackTrace();
			}
			
		}
		
		return u;
	}

	@Override
	public int updatePassword(String newPass, int userid) {
		int i=0;
		try {
			String query="update muser set pass=? where userid=?";
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1, newPass);
			pst.setInt(2, userid);
			i=pst.executeUpdate();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public List<Muser> retriveAll() {
		List<Muser> users = new ArrayList<>();
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from muser");
			while (rs.next()) {
				Muser u = new Muser();
				u.setUserid(rs.getInt("userid"));
				u.setUname(rs.getString("uname"));
				u.setPass(rs.getString("pass"));
				u.setGender(rs.getString("gender"));
				u.setRole(rs.getString("role"));
				users.add(u);
			}
		} catch (SQLException e) {
		e.printStackTrace();
		}
		return users;
	}

}
