package com.training.pl;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.training.pojos.Candidate;
import com.training.service.CandidateService;
import com.training.service.CandidateServiceImpl;

public class CandiadateApp {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		CandidateService candidateService = new CandidateServiceImpl();
		do {
			System.out.println("1.Get List of candidate\n 2. Add Candidate " + "\n 3. List of Candidates(city)"
					+ "\n 4. Sort List of Candidates based on years of experience" + "\n 5. Sort Based on Cities"
					+ "\n 6. List Freshers" + "\n 7. List Highest exprirenced candidate"
					+ "\n 8.candidate count per technolog " + "\n 9.candidate city and skills \n 10.Exit");
			switch (sc.nextInt()) {
			case 1:
				System.out.println("======List Of Candidates==========");
				List<Candidate> candidates = candidateService.getCandidates();
				candidates.forEach(c -> System.out.println(c.getName() + " " + c.getCity() + " "
						+ c.getTechnicalExpertise() + " " + c.getYearsOfExperience()));
				break;
			case 2:
				System.out.println("eneter the Candidate details");
				Candidate can = new Candidate(sc.next(), sc.next(), sc.next(), sc.nextInt());
				candidateService.addCandidate(can);
				System.out.println("Candidate added");
				break;
			case 3:
				System.out.println("List of  Candidates for given city");
				String cityName = sc.next();
				candidateService.getCandidates().stream().filter(c -> c.getCity().equalsIgnoreCase(cityName))
						.forEach(System.out::println);
				break;
			case 4:
				System.out.println("Sort based on expeirence");
				System.out.println("To print the sorted list");
				candidateService.getCandidates().stream()
						.sorted((c1, c2) -> c1.getYearsOfExperience() - c2.getYearsOfExperience())
						.forEach(System.out::println);

				System.out.println("To store into new list");
				List<Candidate> sortedList = candidateService.getCandidates().stream()
						.sorted((c1, c2) -> c1.getYearsOfExperience() - c2.getYearsOfExperience())
						.collect(Collectors.toList());

				System.out.println("With Comparators");
				candidateService.getCandidates().stream()
						.sorted(Comparator.comparingInt(Candidate::getYearsOfExperience)).forEach(System.out::println);

				break;
			case 5:
				System.out.println("sort based on cities");
				candidateService.getCandidates().stream().sorted((c1, c2) -> c1.getCity().compareTo(c2.getCity()))
						.forEach(System.out::println);
				break;
			case 6:
				System.out.println("List of fresher");
				candidateService.getCandidates().stream().filter(c -> c.getYearsOfExperience() == 0)
						.forEach(System.out::println);

				break;
			case 7:
				System.out.println("List of heighest experienced candidate");

				int maxYear = candidateService.getCandidates().stream().map(c -> c.getYearsOfExperience())
						.max(Integer::compare).get();

				candidateService.getCandidates().stream().filter(c -> c.getYearsOfExperience() == maxYear)
						.forEach(System.out::println);
				break;
			case 8:
				System.out.println("candidate count per technology");
				
				Map<Object,List<Candidate>> techCount = candidateService.getCandidates()
																		.stream()
												.collect(Collectors.groupingBy(c-> c.getTechnicalExpertise()));
				for(Entry<Object, List<Candidate>> tech: techCount.entrySet()) {
					System.out.println(tech.getKey()+" "+tech.getValue().size());
				}
				break;
			case 9:
				System.out.println("candidate for entered city and entered skill");
				String cityString= sc.next();
				String skill = sc.next();
				candidateService.getCandidates().stream()
										.filter(c -> c.getCity().equalsIgnoreCase(cityString) 
												&& c.getTechnicalExpertise().equalsIgnoreCase(skill))
										.forEach(System.out::println);
				break;
			case 10:
				System.out.println("Retrive a candidate by index");

				break;
			case 11:
				System.out.println("Thank you");
				sc.close();
				System.exit(0);
			default:
				System.out.println("invalid option");
			}
		} while (true);

	}

}
