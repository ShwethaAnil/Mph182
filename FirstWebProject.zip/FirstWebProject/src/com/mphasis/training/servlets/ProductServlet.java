package com.mphasis.training.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mphasis.training.bos.ProductBo;
import com.mphasis.training.bos.ProductBoImpl;
import com.mphasis.training.exceptions.BuisnessException;
import com.mphasis.training.pojos.Product;

/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("/products")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ProductBo productBo=new ProductBoImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
//		String uname=request.getParameter("uname");
//		pw.print(uname+"<br/>");
//		Cookie[] ck=request.getCookies();
//		for(Cookie c:ck) {
//			if(c.getName().equals("uname")) {
//				pw.print(c.getValue()+"<br/>");
//			}
//		}
		
		HttpSession session=request.getSession(false);
		String name=session.getAttribute("sname").toString();
		pw.print(name+"<br/>"+" "+session.getCreationTime()+" "
		+session.getLastAccessedTime());
		//session.setMaxInactiveInterval(100);
		pw.print("<br/>context Param<br/>");
		ServletContext context=request.getServletContext();
		String cparam=context.getInitParameter("role");
		pw.print(cparam+"<br/>");
		RequestDispatcher rd=request.getRequestDispatcher("menu.html");
		rd.include(request, response);
		try {
			List<Product> products=productBo.getProducts();
			context.setAttribute("products", products);
			pw.print("<table border='1'>");
			pw.print("<tr><th>Product ID</th>"
					+ "<th>Product Name</th>"
					+ "<th>Quantity</th>"
					+ "<th>Cost</th>"
					+ "<th>Ratings</th></tr>");
			for(Product p:products) {
				pw.print("<tr>");
				pw.print("<td>"+p.getPid()+"</td>");
				pw.print("<td>"+p.getPname()+"</td>");
				pw.print("<td>"+p.getQty()+"</td>");
				pw.print("<td>"+p.getCost()+"</td>");
				pw.print("<td>"+p.getRatings()+"</td>");
				pw.print("<td><a href='delete?pid="+p.getPid()+"'>Delete</a></td>");//url rewritting
				pw.print("</tr>");
			}
			pw.print("</table>");
			
		} catch (BuisnessException e) {
			pw.print(e.getMessage());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		Product p=new Product();
		p.setPid(request.getParameter("pid"));
		p.setPname(request.getParameter("pname"));
		p.setQty(Integer.parseInt(request.getParameter("qty")));
		p.setCost(Double.parseDouble(request.getParameter("cost")));
		p.setRatings(Double.parseDouble(request.getParameter("ratings")));
		
		try {
			productBo.addProduct(p);
			pw.print("Product added");
			RequestDispatcher rd=request.getRequestDispatcher("menu.html");
			rd.include(request, response);
		} catch (BuisnessException e) {
			pw.print(e.getMessage());
		}
		
	}

}
