package com.mphasis.training.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String user=request.getParameter("uname");
		String pass=request.getParameter("pass");
		PrintWriter pw=response.getWriter();
		if(user.contains("a")) {
			pw.print("login sucess "+user+"<br/>");
			//url rewritting
			//pw.print("<a href='products?uname='"+user+"'>Products</a>");
			//input type hidden fields
			//pw.print("<form action='products'><input type='hidden' name='uname' value='"+user+"'><input type='submit' value='click'></form>");
			//cookie way
//			Cookie ck=new Cookie("uname", user);
//			response.addCookie(ck);
			//HttpSession
			HttpSession session=request.getSession();//create a new session
			session.setAttribute("sname", user);
			RequestDispatcher rd=request.getRequestDispatcher("menu.html");
			rd.include(request, response);
//			System.out.println("login sucess");
		}else {
			pw.print("Invalid Username and password");
			RequestDispatcher rd=request.getRequestDispatcher("index.html");
			rd.include(request, response);
			//System.out.println("Invalid Username and password");
		}
		pw.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		//response.setContentType("application/msword");
		PrintWriter out=response.getWriter();
		Enumeration<String> en=request.getParameterNames();
		while(en.hasMoreElements()) {
			String name=en.nextElement();
			String[] value=request.getParameterValues(name);
			if(value.length==1) {
				out.println("<br/>"+value[0]);
			}else {
				for(String v:value) {
					out.print("<br/>"+v);
				}
			}
			
		}
		
		
//		String uname=request.getParameter("uname");
//		String pass=request.getParameter("pass");
//		String gender=request.getParameter("gen");
//		String[] lan=request.getParameterValues("lan");
//		PrintWriter pw=response.getWriter();
//		pw.println(uname+" "+pass+" "+gender+" ");
//		for(String l:lan) {
//			pw.print("<li>"+l+"</li>");
//		}
	}

}
