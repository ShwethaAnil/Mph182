package com.mphasis.training.handlers;

import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.jsp.JspException;  
import javax.servlet.jsp.JspWriter;  
 
import java.sql.*;  

public class MyTagPrintHandler extends TagSupport {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id;  
	private String table;  
	  
	public void setId(String id) {  
	    this.id = id;  
	}  
	public void setTable(String table) {  
	    this.table = table;  
	}  
	  
	public int doStartTag()throws JspException{  
	    JspWriter out=pageContext.getOut();  
	    try{   
	        Class.forName("oracle.jdbc.driver.OracleDriver");  
	        Connection con=DriverManager.getConnection(  
	                 "jdbc:oracle:thin:@localhost:1521:xe","java182","java182");  
	        PreparedStatement ps=con.prepareStatement("select * from "+table+" where pid=?");  
	        ps.setString(1,id);  
	        ResultSet rs=ps.executeQuery();  
	        if(rs!=null){  
	        ResultSetMetaData rsmd=rs.getMetaData();  
	        int totalcols=rsmd.getColumnCount();  
	        //column name  
	        out.write("<table border='1'>");  
	        out.write("<tr>");  
	        for(int i=1;i<=totalcols;i++){  
	            out.write("<th>"+rsmd.getColumnName(i)+"</th>");  
	        }  
	        out.write("</tr>");  
	        //column value  
	          
	        if(rs.next()){  
	            out.write("<tr>");  
	                for(int i=1;i<=totalcols;i++){  
	                out.write("<td>"+rs.getString(i)+"</td>");  
	            }  
	            out.write("</tr>");  
	                  
	        }else{  
	            out.write("Table or Id doesn't exist");  
	        }  
	        out.write("</table>");  
	          
	        }  
	        con.close();  
	    }catch(Exception e){System.out.println(e);}  
	    return SKIP_BODY;  
	}  
	
}
