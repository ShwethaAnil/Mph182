package com.mphasis.training.handlers;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class MyTagPowerHandler extends TagSupport {
	private static final long serialVersionUID = 1L;
	private int number;
	private int power;
	private static int counter;
	
	private static int result= 1;
	
	public void setNumber(int number) {
		this.number = number;
	}
	public void setPower(int power) {
		this.power = power;
	}
	@Override
	public int doAfterBody() throws JspException {
		counter++;
		result = result*number; 
		System.out.println("number is "+number+" "+power);
		if(counter == power) 
			return SKIP_BODY;
		else
			return EVAL_BODY_AGAIN;
	}
	@Override
	public int doEndTag() throws JspException {
		JspWriter out=pageContext.getOut();
		
		try {
			out.print(result);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return EVAL_PAGE;
	}
	@Override
	public int doStartTag() throws JspException {
		
		return EVAL_BODY_INCLUDE;
	}
	
	
	
	

}
