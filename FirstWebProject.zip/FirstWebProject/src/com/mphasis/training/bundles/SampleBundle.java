package com.mphasis.training.bundles;

import java.util.ListResourceBundle;

public class SampleBundle extends ListResourceBundle {

	
	static final Object[][] contents = {{"color.Blue","Eligant"},{"color.Cyan","Cry"},
			{"color.gray","Shade of Happy"}};
	
	@Override
	protected Object[][] getContents() {
		return contents;
	}

}
