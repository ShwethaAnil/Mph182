package com.mphasis.training.java8;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateExample {
	
//	enum Status{
//		ORDERED, CONFIRMED, CANCELLED, DESIPACTHED, DELEVERD
//	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Date d1=new Date();
		System.out.println(d1);
		System.out.println(d1.getMonth()+" "+d1.getYear()+" "+d1.getDate());
		Date dob=new Date(1987, 11,03);
		System.out.println(dob);
		
		Calendar cal=new GregorianCalendar();
		System.out.println(cal);
		System.out.println(cal.get(Calendar.DAY_OF_MONTH));
		System.out.println(cal.get(Calendar.DAY_OF_WEEK_IN_MONTH));
		
		Calendar cl1=new GregorianCalendar(1987, 11, 03);
		System.out.println(cl1);
		
		
		//java 8
		//java.time.*;
		LocalDate ld=LocalDate.now();
		System.out.println(ld);
		
		LocalTime lt=LocalTime.now();
		System.out.println(lt);
		
		LocalTime lt1=LocalTime.of(05, 05);
		System.out.println(lt1);
		
		LocalDateTime ldt=LocalDateTime.now();
		System.out.println(ldt);
		
		
		LocalDate dob1=LocalDate.of(1987, 11, 03);
		System.out.println(dob1);
		
		//diffrence between dates
		Period p=Period.between(ld, dob1);
		System.out.println(p);
		//diffrence between time
		Duration du=Duration.between(lt, lt1);
		System.out.println(du);
		
		
		//status --> Ordered, Confirmed, Cancelled, Dispacted, Delivered
		//enum --> set of constants
		
		
//		TrafficSignal[] tf=TrafficSignal.values();
//		
//		for(TrafficSignal t:tf) {
//			System.out.println(t +"  "+t.getN()+" "+t.ordinal());
//		}

	}

}
