package com.mphasis.training.java8;

import java.util.function.Consumer;
import java.util.function.*;



//@FunctionalInterface
interface Cal{
	public double cal(double n1,double n2);
	//public void calc();
	public default void  method1() {
		System.out.println("default method");
	}
	
}

public class LambdaDemo {

	public static void main(String[] args) {
		
		
		Cal c1=new Cal() {
			public double cal(double n1,double n2) {
				return n1+n2;
			}
		};
		
		Cal c2=new Cal() {
			public double cal(double n1,double n2) {
				return n1-n2;
			}
		};
		
		
		Cal c3 = (n1,n2) -> n1*n2;
		
		Cal c4= (n1,n2) -> {
			double div=0;
			if(n2>0) {
				div=n1/n2;
			}
			return div;
		};
		
		System.out.println(c1.cal(34, 678));
		
		
		Consumer<Integer> con=(a)-> System.out.println(a/89);
		con.accept(78);
		
		Predicate<Integer> pr= (n) -> n>78;
		System.out.println(pr.test(34));
		
		Function<Double, Double> fn=(n) -> n+54678;
	
		System.out.println(fn.apply(56.8));
		
		BiPredicate<Integer, Integer> bip= (n,m) -> n>m;
		BiFunction<Integer, Double, Double> bif=(n,m)-> n*m;
		
		
		
		
		
		
		
		
		
		

	}

}
