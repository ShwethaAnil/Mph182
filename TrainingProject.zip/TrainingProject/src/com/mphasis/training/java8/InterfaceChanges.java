package com.mphasis.training.java8;

@FunctionalInterface
interface Account{
	public double withdraw(int amount);
	//public double desposit(int amount);
	public default double payPaytm(int amount) {
		return amount;
	}
	
	public static double payPaypal(int amount) {
		return amount;
	}
	
}

class SavingsAccount implements Account{

	@Override
	public double withdraw(int amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
}

public class InterfaceChanges {

}
