package com.mphasis.training.basics;

import java.util.Scanner;

public class FirstProgram {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Calculator c1=new Calculator();
//		int i=4; //initalization
//	//	while(i<3) { //condition
//		do {
//		System.out.println("Enter the num1 and num2");
//		System.out.println(c1.calcu(sc.nextDouble(), sc.nextDouble(), sc.next()));
//		System.out.println("The Result is ");
//		i++; //increment
//		}while(i<3);
		
		System.out.println("outside for");
		outer:
		for(int j=0;j<5;j++) {
			System.out.println("inside J");
		for(int i=11;i<20;i++) {
			if(i==15){
				break;
			}
			System.out.println(i+" i value is");
		}
		System.out.println(j+" j value is");
		}
		System.out.println("Thank you");
	}

}
