package com.mphasis.training.basics;

public class StringDemo {

	public static void main(String[] args) {
		
		String ss1=new String("Akilesh");
		String ss2= "Akilesh";
		String ss3=new String("Akilesh");
		StringBuffer ss4= new StringBuffer("Akilesh");
		
	System.out.println(ss4);
	ss4.replace(2, 4, "zh");
		System.out.println(ss4);
		
		
		
		
		
		
		// TODO Auto-generated method stub
		String s1="SomeName";// literal
		String s2=new String("sOMEName");//object//heap
		
		// == compraes the primitive data
		//compare the object .equals
		//compare the object with caseinsensitive  equalsIgnoreCase
		
		if(s1.equalsIgnoreCase(s2)) {
			System.out.println(true);
		}else {
			System.out.println(false);
		}
		//compare the string and expect the diffrence
		System.out.println(s1.compareTo(s2));
		System.out.println(s1.compareToIgnoreCase(s2));
		
		System.out.println(s1.charAt(3));
		System.out.println(s1.indexOf('e'));
		System.out.println(s1.replace('e', 's'));
		System.out.println(s1);
		System.out.println(s1.substring(4));
		System.out.println(s1.substring(3, 6));
		System.out.println(s1.codePointAt(3));
	}

}
