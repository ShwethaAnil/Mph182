package com.mphasis.training.basics;

public class Calculator {

	double cal(double n1, double n2, String op){
		System.out.println();
		double result;	
		if(op.equals("+"))
			result = n1+n2;
		else if(op.equals("-"))
			result = n1-n2;
		else if(op.equals("*"))
			result = n1*n2;
		else if(op.equals("/"))
			result = n1/n2;
		else 
			result = 0.0;
		return result;
	}

	double calcu(double n1, double n2, String op){
		double result=0;
		switch(op) {
		case "+": result = n1+n2;
		break;
		case "-": result = n1-n2;
		break;
		case "*": result = n1*n2;
		break;
		case "/": result = n1/n2;
		break;
		case "%": result = n1%n2;
		break;
		default : result = 0;
		}
		return result;
	
	}

		
}
