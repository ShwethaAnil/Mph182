package com.mphasis.training.basics;

public enum TrafficSignal {
	
	RED(60),  ORANGE(05), GREEN(120);
	int n;
	private TrafficSignal() {
		
	}
	private TrafficSignal(int num) {
		this.n=num;
	}
	
	public int getN() {
		return n;
	}
}
