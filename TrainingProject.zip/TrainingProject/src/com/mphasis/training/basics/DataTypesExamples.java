package com.mphasis.training.basics;

public class DataTypesExamples {

	public static void main(String[] args) {
		boolean b=false;
		byte  a = 126;// -128 to 127
		short s = 32767;// -32768 to 32767
		int  i = 1234567890;// (2^31 -1 )  // -2147483648 to  2147483647
		long l = 7829181823l; // -9223372036854775808 (-2^63) to (2^63-1)
		float f1 = 2345.67f;
		double d1= 12.3;
		char c1= 'A';
		char c2= 'a';
		char c3 = 65;
		char c4 = '\u0098';// \u0000 to \uffff 
		System.out.println(c4);
		
		//opertaors:
		//1. Arithmatic   +,- ,*, /, %
		//2. Relaltional  < > <= >= == !=
		//3. Assignment  = 
		//4. Logical Operators  &&, ||, !
		//5. Ternary Operator   ?:
		//6. Shift operator << >> >>>
		//7. Bitwise   &, | , ^
		//8. Unary Operator  ++, --
		// i++ post increment,  ++i pre increment
		int n1=13;
		System.out.println(n1++);
		System.out.println(++n1);
		
		System.out.println(~n1);
		
		//predence
		 // * division substraction addition
		
		System.out.println(10*10/5+(3-1)*4/2);
		
		System.out.println(14<<2); // 14*2^2 
		System.out.println(14<<3); // 14*2^3
		
		System.out.println(14>>2); // 14/2^2;
		System.out.println("Cap");
		System.out.println(2^3);
		
		
		System.out.println(3>2 && 10<9);
		
	int min = (5<6)?5:6;
		System.out.println(min);
		
		n1=n1+45;
		n1+=45;
		
		
		int num1=3456789;
		double d4=num1; //widening
		System.out.println(d4);
		
		double d5=5678.987;
		int n5=(int)d5;//narrowing
		
		System.out.println(n5);
		
		char a5='A';
		int n6= a5;
		
		char a6=(char) n6;
		
		
		//Control Statments
		//1. Conditional Control Statment --> if, if.. else, if..else if..else if..else, switch
		//2. Unconditional Control Statment  -- break, continue, break label, continue label
		//3. Looping --> while(pre testing loop), do while(post testing), for
		
		
		
		
		
		
		
		
		

	}

}
