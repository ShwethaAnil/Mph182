package com.mphasis.training.basics;

import java.util.Arrays;

public class ArrayDemo {

	public static void main(String[] args) {
	
		int[] arr = {12,34,56,78,23,34};
		//int arr1[]=new int[5];
		
		System.out.println("Traditional For loop");
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		
		System.out.println("Enchanced For loop");
		for(int a:arr) {
			System.out.println(a);
		}
		
		String[] names=new String[5];
		names[0]="Anjali";
	//	names[1]="Anusha";
		names[2]="Chandana";
		names[3]="Vinutha";
		names[4]="Manasa";
		names[1]="Soma";
		
		for(String s:names) {
			System.out.println(s);
		}
		System.out.println("After Sort");
		Arrays.sort(names);
		for(String s:names) {
			System.out.println(s);
		}
		
		System.out.println();
		
		//Multidimension array
//		int[][] d2arr = new int[3][3];
//		d2arr[0][0]=78;
		
		int[][] twoDarr = {{12,45},{34,56},{89,45}};
		
		System.out.println(twoDarr.length);
		
//		for(int i=0;i<twoDarr.length;i++) {
//			for(int j=0;j<twoDarr.length;j++) {
//				System.out.print(twoDarr[i][j]+"\t");
//			}
//			System.out.println();
//		}
		
		for(int[] n1:twoDarr) {
			for(int n2:n1) {
				System.out.print(n2+" \t");
			}
			System.out.println();
		}
		
		
	}

}
