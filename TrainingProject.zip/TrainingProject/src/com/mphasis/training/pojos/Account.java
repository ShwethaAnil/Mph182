package com.mphasis.training.pojos;

import java.util.Date;
public class Account {
	
private	long accNum;
private	double balance;
private	Date acc_created_date;
private	String acc_type;
private	String branch_address;
private	Customer customer;
//zero balance account creation
//opening balance 1000 account
//public Account() {
//	
//}
//constructor overloading
public Account(long accNum,String acc_type,String branch_address,
		long adarNum, String pan,String name,String add,String dob,long phnum,String email) {
	this.accNum= accNum;
	this.acc_created_date= new Date();
	this.acc_type=acc_type;
	this.branch_address= branch_address;
	customer=new Customer(adarNum, pan, name, add, dob, phnum, email);	
}	
public Account(long accNum,double balance,String acc_type,String branch_address,
		long adarNum, String pan,String name,String add,String dob,long phnum,String email) {
	this.accNum= accNum;
	this.balance=balance;
	this.acc_created_date= new Date();
	this.acc_type=acc_type;
	this.branch_address= branch_address;
	customer=new Customer(adarNum, pan, name, add, dob, phnum, email);	
}

public long getAccNum() {
	return accNum;
}

public void setAccNum(long accNum) {
	this.accNum = accNum;
}

public double getBalance() {
	return balance;
}

public void setBalance(double balance) {
	this.balance = balance;
}

public Date getAcc_created_date() {
	return acc_created_date;
}

public void setAcc_created_date(Date acc_created_date) {
	this.acc_created_date = acc_created_date;
}

public String getAcc_type() {
	return acc_type;
}

public void setAcc_type(String acc_type) {
	this.acc_type = acc_type;
}

public String getBranch_address() {
	return branch_address;
}

public void setBranch_address(String branch_address) {
	this.branch_address = branch_address;
}

public Customer getCustomer() {
	return customer;
}

public void setCustomer(Customer customer) {
	this.customer = customer;
}

@Override
public String toString() {
	return "Account [accNum=" + accNum + ", balance=" + balance + ", acc_created_date=" + acc_created_date
			+ ", acc_type=" + acc_type + ", branch_address=" + branch_address + ", customer=" + customer + "]";
}



}
