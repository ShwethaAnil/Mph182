package com.mphasis.training.pojos;

public class Customer {
	//instance variables
	private	 long adarNum; // public void setAdarNum(long adarNum){this.adarNum=adarNum}
	private	 String panNum;
	private	 String cName;
	private	 String address;
	private	 String dob;
	private	 long phnum;
	private	 String email;
	public Customer(long adarNum, String panNum, String cName, String address, String dob, long phnum, String email) {
		super();
		this.adarNum = adarNum;
		this.panNum = panNum;
		this.cName = cName;
		this.address = address;
		this.dob = dob;
		this.phnum = phnum;
		this.email = email;
	}
	public long getAdarNum() {
		return adarNum;
	}
	public void setAdarNum(long adarNum) {
		this.adarNum = adarNum;
	}
	public String getPanNum() {
		return panNum;
	}
	public void setPanNum(String panNum) {
		this.panNum = panNum;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public long getPhnum() {
		return phnum;
	}
	public void setPhnum(long phnum) {
		this.phnum = phnum;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Customer [adarNum=" + adarNum + ", panNum=" + panNum + ", cName=" + cName + ", address=" + address
				+ ", dob=" + dob + ", phnum=" + phnum + ", email=" + email + "]";
	}
	
	
	
	
}
