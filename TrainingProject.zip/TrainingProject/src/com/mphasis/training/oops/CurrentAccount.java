package com.mphasis.training.oops;

public class CurrentAccount extends Account {

	private int overdraftLimit = 50000;
	
	
	
	public int getoverdraftLimit() {
		return overdraftLimit;
	}

	public void setoverdraftLimit(int overdraftoverdraftLimit) {
		this.overdraftLimit = overdraftoverdraftLimit;
	}

	public CurrentAccount(long accNum, String acc_holder_name, double balance) {
		super(accNum, acc_holder_name, balance);
		// TODO Auto-generated constructor stub
	}

////withdraw --> till overdraft overdraftLimit  amount withdraw
	//deposit --> negative amount cannot deposit
//	@Override
//	public double withdraw(int amount) {
//		if(amount > 0) {
//			if(balance+overdraftoverdraftLimit-amount>=0) {
//				//balance= balance+overdraftoverdraftLimit;
//				balance= balance-amount;
//				
//			}else {
//				System.out.println("Overdraft overdraftLimit reached");
//			}
//			}else {
//				System.out.println("min balance 1000 should maintain");
//			}
//			return balance+overdraftoverdraftLimit;
//	}
	
//	public double withdraw(int amount) {
//        if(amount > 0 && amount < balance) {
//            balance= balance-amount;
//            System.out.println("OverDraft overdraftLimit = "+ overdraftoverdraftLimit);
//        }
//        else if(amount> balance && amount < (balance+overdraftoverdraftLimit)) {
//            overdraftoverdraftLimit = (int) (overdraftoverdraftLimit - (amount-balance));
//            balance = balance-amount;
//            
//            System.out.println("OverDraft overdraftLimit = "+ overdraftoverdraftLimit);
//        }else if(overdraftoverdraftLimit == 0 || amount>overdraftoverdraftLimit){
//            System.out.println("OverDraft overdraftLimit Exceeded");
//        }
//        return balance;
//    }
	
	protected double withdraw(int amount) {
        if(amount>0)
        {
            if(balance-amount+overdraftLimit>=0)
            {
                balance= balance - amount;
                if(balance<0 && overdraftLimit>0)
                {
                    overdraftLimit= (int) (overdraftLimit+ balance);
                    balance=0;
                    
                }
                System.out.println("Your Overdraft :" +overdraftLimit);
            }
            else 
            {
                System.out.println("Your reached to your overdraftLimit");
            }
        }
        return balance;
    }

	@Override
	public double deposit(int amount) {
		
		return super.deposit(amount);
	}
	
	
	

}
