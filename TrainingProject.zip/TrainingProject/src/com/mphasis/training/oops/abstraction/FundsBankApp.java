package com.mphasis.training.oops.abstraction;

public class FundsBankApp {
	
	public static void main(String[] args) {
		
		Account.method1();
		//Account a2=new Account(1234,"Krishna",54678900);
		
		CurrentAccount a1=new CurrentAccount(12345,"Aman",10000);
		System.out.println(a1);
		System.out.println(a1.withdraw(4000)); // balance= 1000 + overdraft limit=50000
		System.out.println(a1);
		System.out.println(a1.withdraw(4000));
		System.out.println(a1);
		System.out.println(a1.withdraw(40000));
		System.out.println(a1);
		System.out.println(a1.withdraw(20000));
		
// withdraw --> min balance 1000 should maintain
		//deposit --> multiples of 100 should allow
		
		
//withdraw --> overdraft limit
		//deposit --> negative amount cannot deposit
	}

	static{
		System.out.println("Code Static Block");
	}
}
