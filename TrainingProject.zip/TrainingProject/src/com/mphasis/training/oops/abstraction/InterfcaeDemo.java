package com.mphasis.training.oops.abstraction;

interface Shape{
	//by default will take only final variables and abstract method till java 8
	 double PI = 3.14;
	public double area();
}

class Traingle implements Shape{
	
	private int height;
	private int base;
	
	

	public Traingle(int height, int base) {
		super();
		this.height = height;
		this.base = base;
	}



	@Override
	public double area() {
		// TODO Auto-generated method stub
		return 0.5*base*height;
	}	
}

class Circle implements Shape{
	
	private int radius;
	//public  final int X=98;
	
	Circle(int r){
		radius =r;
	}
	
	@Override
	public double area() {
		// TODO Auto-generated method stub
		return PI*radius*radius;
	}	
}

public class InterfcaeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Circle c1=new Circle(4567);
System.out.println(c1.area());


	}

}
