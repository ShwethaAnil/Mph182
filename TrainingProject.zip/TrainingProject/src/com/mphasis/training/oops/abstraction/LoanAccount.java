package com.mphasis.training.oops.abstraction;

public class LoanAccount extends Account {

	public LoanAccount(long accNum, String acc_holder_name, double balance) {
		super(accNum, acc_holder_name, balance);
	}

	@Override
	public double withdraw(int amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double deposit(int amount) {
		// TODO Auto-generated method stub
		return 0;
	}

}
