package com.mphasis.training.oops;

class Calculator{
	public int add(int a,int b) {
		System.out.println("int");
		return a+b;
	}
	
	public int add(int a,int b,int c, int d) {
		System.out.println("int");
		return a+b+c+d;
	}
	
	public String add(int a,String b) {
		return a+b;
	}
	
	public String add(String a,int b) {
		return a+b;
	}
//	public double add(double a,double b) {
//		System.out.println("double");
//		return a+b;
//	}
	
	public float add(int a,float b) {
		System.out.println("int float");
		return a+b;
	}
	
//	public float add(float a,int b) {
//		System.out.println("float int");
//		return a+b;
//	}
	
	public float add(float a,float b) {
		System.out.println("float float");
		return a+b;
	}
//	public double add(float a,float b) {
//		System.out.println("float float");
//		return a+b;
//	}
}

public class MethodOverloadingExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculator c=new Calculator();
		System.out.println(c.add(45.9f, 78));
	}

}
