package com.mphasis.training.oops;

public class FundsBankApp {

	public static void main() {
		System.out.println("Main method without args");
	}
	
	public static void main(int[] a) {
		System.out.println("Main method without args");
	}
	
	public static void display(String... values) {//java 5
		System.out.println("display method invoked");
		for(String v:values) {
		System.out.println(v);
		}
	}
	
	 public static void main(String args[]) {
		
		FundsBankApp.display();
		FundsBankApp.display("Ankita");
		FundsBankApp.display("Ankita", "Anjali");
		FundsBankApp.display("Ankita", "Anjali","Rishika","Aman","Prakar","Vinutha");
		
		
		
		
		Account a1=new CurrentAccount(12345,"Aman",10000);//upcasting
		
		((CurrentAccount) a1).getoverdraftLimit();
		
		//CurrentAccount c1=new Account(0, null, 0);
		CurrentAccount c1= (CurrentAccount) a1;//downcasting
		System.out.println(a1);
		System.out.println(a1.withdraw(4000)); // balance= 1000 + overdraft limit=50000
		System.out.println(a1);
		System.out.println(a1.withdraw(4000));
		System.out.println(a1);
		System.out.println(a1.withdraw(40000));
		System.out.println(a1);
		System.out.println(a1.withdraw(20000));
		
// withdraw --> min balance 1000 should maintain
		//deposit --> multiples of 100 should allow
		
		
//withdraw --> overdraft limit
		//deposit --> negative amount cannot deposit
	}

}
