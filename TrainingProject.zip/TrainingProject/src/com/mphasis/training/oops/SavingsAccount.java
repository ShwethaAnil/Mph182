package com.mphasis.training.oops;

public class SavingsAccount extends Account{

	public SavingsAccount(long accNum, String acc_holder_name, double balance) {
		super(accNum, acc_holder_name, balance);
	}
	public double withdraw(int amount) {
		if((balance-amount) >= 1000 && amount > 0) {
		balance= balance-amount;
		}else {
			System.out.println("min balance 1000 should maintain");
		}
		return balance;
	}
	
	public double deposit(int amount) {
		if( (amount% 100) == 0) {
		balance= balance+amount;
		}else {
			System.out.println("Only multiples of 100 is allowed for deposit");
		}
		return balance;
	}
	////withdraw --> till overdraft limit  amount withdraw
	//deposit --> negative amount cannot deposit
}
