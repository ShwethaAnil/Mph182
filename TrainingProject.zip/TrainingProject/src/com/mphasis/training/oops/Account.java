package com.mphasis.training.oops;

public class Account {
	
	private long accNum;
	private String acc_holder_name;
	protected double balance;
	
	
	
	 double withdraw(int amount) {
		balance=balance-amount;
		return balance;
	}
	
	public double deposit(int amount) {
		balance=balance+amount;
		return balance;
	}
	
	
	public Account(long accNum, String acc_holder_name, double balance) {
		super();
		this.accNum = accNum;
		this.acc_holder_name = acc_holder_name;
		this.balance = balance;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public String getAcc_holder_name() {
		return acc_holder_name;
	}
	public void setAcc_holder_name(String acc_holder_name) {
		this.acc_holder_name = acc_holder_name;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", acc_holder_name=" + acc_holder_name + ", balance=" + balance + "]";
	}
	
	

}
