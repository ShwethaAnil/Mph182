package com.mphasis.training.exceptions;

public class InvalidNumberExcpetion extends Exception{

	public InvalidNumberExcpetion(String message) {
		super(message);
	}
}
