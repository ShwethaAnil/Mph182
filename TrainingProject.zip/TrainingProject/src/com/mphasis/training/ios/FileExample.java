package com.mphasis.training.ios;

import java.io.File;
import java.io.IOException;

public class FileExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File  file=new File("java1234.txt");
		try {
//			if(file.createNewFile()) {
//				System.out.println("File is created");
//			}else {
//				System.out.println("File already exists");
//			}
			file.createNewFile();
			System.out.println(file);
			File file2=file.getCanonicalFile();
			System.out.println(file2);
			
			File file3= file.getAbsoluteFile();
					System.out.println(file3);
			
			boolean status= file.exists();
			System.out.println(status);
			
			File f=new File("F:\\trainings\\Mphasis\\2020 Java batch\\182 batch\\sessions\\java\\projects\\TrainingProject");
			File fileNames[]=f.listFiles();
			for(File filename: fileNames) {
				if(filename.isDirectory()) {
					System.out.println(filename+"it is a directory");
				}else {
				System.out.println(filename);
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
