package com.mphasis.training.ios;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class WriteMultipleExample {

	public static void main(String[] args)throws IOException {
		
		FileOutputStream fout1=new FileOutputStream("example1.txt");
		FileOutputStream fout2=new FileOutputStream("example2.txt");
		
		ByteArrayOutputStream bout=new ByteArrayOutputStream();
		String s1="File handling code";
		bout.write(s1.getBytes());
		
		bout.writeTo(fout1);
		bout.writeTo(fout2);
		
		bout.flush();
		bout.close();
		
		fout1.close();
		fout2.close();
	}

}
