package com.mphasis.training.ios;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferExample {

	public static void main(String[] args)throws IOException {
		FileOutputStream fos=null;
		BufferedOutputStream bos=null;
		try {
		fos=new FileOutputStream("sample1.txt",true);
		bos=new BufferedOutputStream(fos);
		String sam="Sample content";
		bos.write(sam.getBytes());
		
		}catch(FileNotFoundException  e) {
			System.out.println(e.getMessage());
		}catch(IOException e) {
			System.out.println(e.getMessage());
		}finally {
			bos.flush();
			fos.flush();
			bos.close();
			fos.close();
		}
		
		//System.out.println("completed");
		FileInputStream fis=null;
		BufferedInputStream bis=null;
		try {
		fis=new FileInputStream("sample1.txt");
		bis=new BufferedInputStream(fis);
		int i=0;
		while((i=bis.read()) !=-1) {
		System.out.print((char)i);
		}
		}catch(IOException e) {
			e.printStackTrace();
		}
		bis.close();
		fis.close();

	}

}
