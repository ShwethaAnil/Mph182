package com.mphasis.training.ios;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileWriteExample {

	public static void main(String[] args) throws IOException {
		FileOutputStream fos=null;
		try {
		fos=new FileOutputStream("sample1.txt",true);
		String sam="Sample content";
		fos.write(sam.getBytes());
	
		}catch(FileNotFoundException  e) {
			System.out.println(e.getMessage());
		}catch(IOException e) {
			System.out.println(e.getMessage());
		}finally {
			fos.close();
		}
		
		//System.out.println("completed");
		FileInputStream fis=null;
		try {
		fis=new FileInputStream("sample1.txt");
		int i=0;
		while((i=fis.read()) !=-1) {
		System.out.print((char)i);
		}
		}catch(IOException e) {
			e.printStackTrace();
		}
		fis.close();
	}

}
