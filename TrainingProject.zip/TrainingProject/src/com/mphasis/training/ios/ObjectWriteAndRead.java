package com.mphasis.training.ios;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.mphasis.training.pojos.Product;

public class ObjectWriteAndRead {

	public static void main(String[] args)throws IOException, ClassNotFoundException {
		
		Product p=new Product("P12","Watch",23,45678,4);
		//write object to file
		FileOutputStream fos=new FileOutputStream("products.txt");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(p);
		oos.flush();
		fos.flush();
		
		oos.close();
		fos.close();
		System.out.println("Done");
		
		//read object from file
		FileInputStream fis=new FileInputStream("products.txt");
		ObjectInputStream ois=new ObjectInputStream(fis);
		Product p1=(Product)ois.readObject();
		
		System.out.println(p1);
		
		ois.close();
		fis.close();
		
		
		
		
		
		
		
		
		

	}

}
