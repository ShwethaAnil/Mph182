package com.mphasis.training.ios;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.SequenceInputStream;

public class MultipleFilesReadExample {

	public static void main(String[] args)throws IOException {
		FileInputStream file1=new FileInputStream("sample.txt");
		FileInputStream file2 =new FileInputStream("sample1.txt");
		
		SequenceInputStream sis=new SequenceInputStream(file1, file2);
		
		FileOutputStream output=new FileOutputStream("result.txt");
		int i=0;
		while((i=sis.read()) !=-1) {
			output.write((char)i);
			System.out.print((char)i);
		}
		output.flush();
		output.close();
		sis.close();
		file2.close();
		file1.close();
	}

}
