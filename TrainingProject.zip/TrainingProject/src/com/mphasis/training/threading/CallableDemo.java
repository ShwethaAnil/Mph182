package com.mphasis.training.threading;

import java.util.concurrent.Callable;

class CallableThread implements Callable<Integer>{

	@Override
	public Integer call() throws Exception {
		int cnt=0;
		for(;cnt<5;cnt++) {
			System.out.println("Callable "+cnt);
		}
		return cnt;
	}
	
}


public class CallableDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
