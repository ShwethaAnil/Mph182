package com.mphasis.training.threading;

public class BuApp {

	public static void main(String[] args) {
		Bus b1=new Bus();
		Passenger p1=new Passenger(25,b1,"Anjali");
		Passenger p2=new Passenger(26, b1, "Dakshayini");
		
		p1.start();
		p2.start();
		

	}

}
