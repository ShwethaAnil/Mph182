package com.mphasis.training.threading;

public class ThreadGroupDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ThreadGroup tg1=new ThreadGroup("FRS");
		ThreadGroup tg2= new ThreadGroup("DES");
		
		Thread t1=new Thread(tg1, "Vaishnavi");
		
		Thread t2=new Thread(tg2, "Vinutha");
		
		tg1.setMaxPriority(Thread.MAX_PRIORITY-1);
		tg1.activeCount();tg1.activeGroupCount();
		

		System.out.println("Background Thread");
		t1.setDaemon(true);
		
		System.out.println(t1.isDaemon());
		
		
		
	}
	

}
