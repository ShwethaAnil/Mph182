package com.mphasis.training.threading;

class Table{
	public static synchronized void printTable(int number) {
		for(int i=1;i<=10;i++) {
			System.out.println(number+"*"+i+"="+(number*i));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

class MyThread extends Thread{
	Table t;
	MyThread(Table t){
		this.t=t;
	}
	public void run() {
		Table.printTable(7);
	}
}

class MyThread1 extends Thread{
	Table t;
	MyThread1(Table t){
		this.t=t;
	}
	public void run() {
		Table.printTable(12);
	}
}

class MyThread2 extends Thread{
	Table t;
	MyThread2(Table t){
		this.t=t;
	}
	public void run() {
		t.printTable(4);
	}
}

class MyThread3 extends Thread{
	Table t;
	MyThread3(Table t){
		this.t=t;
	}
	public void run() {
		t.printTable(19);
	}
}

public class SynchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Table table=new Table();
		MyThread t1=new MyThread(table);
		MyThread1 tt1=new MyThread1(table);
		tt1.setPriority(10);
		t1.start();
		tt1.start();
		
		Table table1=new Table();
		MyThread2 t2=new MyThread2(table1);
		MyThread3 t21=new MyThread3(table1);
		t21.setPriority(10);
		t2.start();
		t21.start();
	}

}
