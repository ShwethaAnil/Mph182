package com.mphasis.training.threading;

public class Bus implements Runnable {

	private int totalSeatsAvailable = 30;
	
	
	
	public boolean bookTicket(int seats, String name) {
		System.out.println("Welcome to Mphasis 182 Bus"+ Thread.currentThread().getName()
				+", Seats Available = "+this.getTotalSeatsAvailable());
		if(seats> this.getTotalSeatsAvailable()) {
			return false;
			
		}else {
			totalSeatsAvailable = totalSeatsAvailable -seats;
			return true;
		}
	}
	
	
	@Override
	public void run() {
		Passenger pt= (Passenger) Thread.currentThread();
		boolean ticketBooked = this.bookTicket(pt.getSeatsNeeded(), pt.getName());
		if(ticketBooked == true) {
			System.out.println("Congrats, "+Thread.currentThread().getName()+" "+pt.getSeatsNeeded()+" are booked");
		}else {
			System.out.println("Sorry, "+Thread.currentThread().getName()+" "+pt.getSeatsNeeded()+" are not booked");
		}
	}


	public int getTotalSeatsAvailable() {
		return totalSeatsAvailable;
	}

}
