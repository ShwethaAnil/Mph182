package com.mphasis.training.threading;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class Task implements Runnable{
	
	public void run() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Thread Name"+Thread.currentThread().getName());
	}
	
}

public class ThreadPoolDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ExecutorService eService=Executors.newCachedThreadPool();
		for(int i=0;i<50;i++) {
			eService.execute(new Task());
		}
		
	}

}
