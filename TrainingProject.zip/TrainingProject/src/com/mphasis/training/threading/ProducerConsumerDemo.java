package com.mphasis.training.threading;


class Market{
	
	private boolean v=true;
	
	public synchronized void produced(int i) throws InterruptedException {
		if(!v)
			wait();
		System.out.println("Produced "+i);
		v=false;
		notify();
	}
	
	public synchronized void consumed(int i) throws InterruptedException {
		if(v)
			wait();
		System.out.println("Consumed "+i);
		v=true;
		notify();
	}
	
}

class Producer extends Thread{
	Market m;
	Producer(Market m){
		this.m=m;
	}
	
	public void run() {
		for(int i=0;i<10;i++) {
			try {
				m.produced(i);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

class Consumer extends Thread{
	Market m;
	Consumer(Market m){
		this.m=m;
	}
	
	public void run() {
		for(int i=0;i<10;i++) {
			try {
				m.consumed(i);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
public class ProducerConsumerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Market m1=new Market();
 Producer p1=new Producer(m1);
 Consumer c1=new Consumer(m1);
 p1.start();
 c1.start();
		
		
	}

}
