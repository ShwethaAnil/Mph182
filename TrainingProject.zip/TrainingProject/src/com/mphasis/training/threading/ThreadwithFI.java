package com.mphasis.training.threading;

public class ThreadwithFI {

	public static void main(String[] args) {
	
		
		//java 8
	Thread tt1=new Thread(() -> {
			for(int i=0;i<5;i++) {
				System.out.println("Greet");
			}
	});
		
	}

}


