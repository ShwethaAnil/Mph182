package com.mphasis.training.threading;


class Hello implements Runnable{
//	public Hello(String name) {
//		super(name);
//	}
	public void run() {
		for(int i=0;i<5;i++) {
		System.out.println("Hello");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		}
	}
}

class Hi extends Thread{
	public void run() {
		for(int i=0;i<5;i++) {
		System.out.println("Hi");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		}
	}
}

public class MultithreadDemo {

	public static void main(String[] args)throws InterruptedException {
	Hello h1=new Hello();//runnable object
	Thread t1=new Thread(h1,"Sudaharsan");
	Hi h2=new Hi();
	t1.start();
	h2.start();
	t1.setPriority(Thread.NORM_PRIORITY+1);
	//h2.start();
	//h2.setName("Sudarshan");
	//h1.setName("Akilesh");
	System.out.println(t1.getName()+" "+t1.getPriority()+" "+t1.getId());
	System.out.println(h2.getName()+" "+h2.getPriority()+" "+h2.getId());
	System.out.println("Priority "+t1.getPriority()+" "+ h2.getPriority());
	System.out.println("live status "+t1.isAlive());
	t1.join();
	h2.join();
	
	System.out.println("Live status "+h2.isAlive());
	System.out.println("Done");
	}

}
