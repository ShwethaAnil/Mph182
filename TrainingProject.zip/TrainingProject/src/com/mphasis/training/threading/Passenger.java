package com.mphasis.training.threading;

public class Passenger extends Thread {

	private int seatsNeeded;
	public Passenger(int seats, Bus target, String name) {
		super(target,name);
		this.seatsNeeded = seats;	
	}
	
	public int getSeatsNeeded() {
		return seatsNeeded;
	}
	
//	public void run() {
//		System.out.println("Passenger run");
//	}
}
