package com.mphasis.training.pl;

import java.util.Scanner;

import com.mphasis.training.exceptions.InvalidNumberExcpetion;

class Calc{
	public double div(int a,int b) throws InvalidNumberExcpetion {
		double div=0;
		if(a>10) {
			div=a/b;
		}else {
			throw new InvalidNumberExcpetion("a shoule be greater than 10");
		}

		return div;
	}
}

public class SampleApp {

	public static void main(String[] args) throws InvalidNumberExcpetion {
		Calc c1=new Calc();
		System.out.println("div result is "+c1.div(8,0));
//		try {
//			System.out.println("div result is "+c1.div(8,0));
//		} catch (InvalidNumberExcpetion e) {
//			e.printStackTrace();
//		}
//		
		System.out.println("code continuees");
		
//		Scanner sc=new Scanner(System.in);
//		
//		int n1= sc.nextInt();
//		int n2=sc.nextInt();
//	try {
//		double div=n1/n2;
//		System.out.println("result is "+div);
//	}catch(ArithmeticException e) {
//		e.printStackTrace();
//	}finally {
//		System.out.println("finally block");
//	}
//		String s1=sc.next();
//		try {
//		System.out.println(s1.charAt(7));
//		}catch(Exception e) {
//			System.out.println(e.getMessage());
//		}
//		System.out.println("Enter the size of array");
//		int arr[]=new int[sc.nextInt()];
//		try {
//		System.out.println(arr[8]);
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
		System.out.println("code continuessss");
//		int n1= sc.nextInt();
//		int n2=sc.nextInt();
//		if(n2>0) {
//		double div=n1/n2;
//		System.out.println("result is "+div);
//		}
//		String s1=sc.next();
//		if(s1.length()>=7) {
//		System.out.println(s1.charAt(7));
//		}
//		System.out.println("Enter the size of array");
//		int arr[]=new int[sc.nextInt()];
//		if(arr.length>=8) {
//		System.out.println(arr[8]);
//		}
//		System.out.println("code continuessss");
	}

}
