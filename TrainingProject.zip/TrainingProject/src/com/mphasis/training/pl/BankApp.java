package com.mphasis.training.pl;

import java.util.Scanner;
import com.mphasis.training.pojos.Account;
import com.mphasis.training.pojos.Customer;

public class BankApp {
	public static void main(String[] args) {
		System.out.println("Welcome to Mphasis Bank");
		Scanner sc=new Scanner(System.in);
		
		do {
			System.out.println("1.Zero balance account \n 2. Open Balance account");
			int choice=sc.nextInt();
			if(choice == 1) {
				Account a=new Account(123, "SA", "bangalore", 34567, "dfgh567", "Soma", "RRnagar", "12-Nov-1998", 3456789, "fghjkl");
				System.out.println("Account Created");
				System.out.println(a);
			}else if(choice == 2){
				Account a=new Account(123, 1000, "SA", "bangalore", 34567, "dfgh567", "Soma", "RRnagar", "12-Nov-1998", 3456789, "fghjkl");
				System.out.println("Account Created");
				System.out.println(a);
			}else {
				System.out.println("Invalid Option");
			}
		}while(true);
		
		
		
		
		
		
		
		
		
		
		
//		do {
//		System.out.println("1.Create Account \n 2.Get CustomerNames \n 3.Exit");
//		Account a1=new Account();
//		Account acc=new Account(123, 456789, "SA", "RRNagar, Banaglore",12323, "CXJPS601B", "Shwetha", "RajajiNagar, Banagalore", "03-Nov-1987", 345678900987l, "guptha.shwetha@gmail.com");
//		//acc.createAccount();
//		Customer c= acc.getCustomer();
//		
//		switch(sc.nextInt()) {
//		case 1: System.out.println("Enter your details");
//		//System.out.println("Enter which type of account you want? SA or CA");
//		//acc.createAccount(123, 456789, "30-Dec-2020", "SA", "RRNagar, Banaglore");
//		Customer c1= acc.getCustomer();
//		//c1.createCustomer(12323, "CXJPS601B", "Shwetha", "RajajiNagar, Banagalore", "03-Nov-1987", 345678900987l, "guptha.shwetha@gmail.com");
//		System.out.println(acc);
//		break;
//		case 2: System.out.println("Monthly Statement");
//		Customer c4=acc.getCustomer();
//		System.out.println(c4.getAdarNum());
//		c4.setAdarNum(56789);
//		System.out.println(c4.getAdarNum());
//		break;
//		case 3: System.out.println("Thank You");
//				sc.close();
//				System.exit(0);
//		default: System.out.println("Invalid Option");		
//		}
//		}while(true);
	}

}
