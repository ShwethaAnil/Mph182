package com.mphasis.training;



public class Hdd {
	public Hdd() {
		System.out.println("constructor Called");
	}

}
