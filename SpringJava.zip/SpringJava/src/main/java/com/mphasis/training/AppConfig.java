package com.mphasis.training;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

@Configuration
public class AppConfig {
	
	@Bean
	@Lazy
	@Scope("prototype")
	public Processor getSnapDragon() {
		Processor processor=new SnapDragon();
		return processor;
	}
	
	@Bean
	public Processor getI5Processor() {
		Processor processor=new I5Prcoessor();
		return processor;
	}
	
	@Bean
	public Hdd getHdd() {
		Hdd hdd=new Hdd();
		return hdd;
	}
	
	@Bean
	public Laptop getLaptop() {
		Laptop lp=new Laptop();
		lp.setProcessor(getSnapDragon());
		lp.setHardDisk(getHdd());
		return  lp;
	}

}
