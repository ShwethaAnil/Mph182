package com.mphasis.training;


import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //ApplicationContext context=new ClassPathXmlApplicationContext("application.xml");
    	ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);       
        Laptop l1=(Laptop) context.getBean(Laptop.class);
        l1.setModelNum(323);
        l1.setBrand("MAc");
        l1.setRamsize("8 GB");
        System.out.println(l1);
        
        ((AbstractApplicationContext) context).close();
        System.out.println("Spring with Annotation");
        
//        Laptop lp=(Laptop) context.getBean("l2");
//        System.out.println(lp);
////        
//        
//        System.out.println(l1);
//        
//        Laptop l2=(Laptop) context.getBean("l1");
//        l2.setModelNum(324);
//        l2.setBrand("HP");
//        l2.setProcessor("snapDragon");
//        l2.setRamsize("8 GB");
//        
//        System.out.println(l2);
//        System.out.println(l1);
        
    }
}
