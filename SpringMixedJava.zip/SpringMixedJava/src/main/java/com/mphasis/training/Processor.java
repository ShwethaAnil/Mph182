package com.mphasis.training;


public interface Processor {
	
	public void process();

}
