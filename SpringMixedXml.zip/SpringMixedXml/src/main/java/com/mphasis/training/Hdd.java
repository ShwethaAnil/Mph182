package com.mphasis.training;

import org.springframework.stereotype.Component;

@Component
public class Hdd {
	public Hdd() {
		System.out.println("constructor Called");
	}

}
