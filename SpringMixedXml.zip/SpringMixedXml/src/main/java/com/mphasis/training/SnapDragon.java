package com.mphasis.training;

import org.springframework.stereotype.Component;

@Component
public class SnapDragon implements Processor {
	
	public SnapDragon() {
		System.out.println("Snap Called");
	}

	@Override
	public void process() {
		// TODO Auto-generated method stub

	}

}
