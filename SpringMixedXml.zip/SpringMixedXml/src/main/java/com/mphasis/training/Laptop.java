package com.mphasis.training;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;



@Component
@Lazy
@Scope("prototype")
public class Laptop implements InitializingBean, DisposableBean {
	
	private int modelNum;
	private String brand;
	private String  ramsize;
	@Autowired
	@Qualifier(value="snapDragon")
	private Processor processor;
	@Autowired
	private Hdd hardDisk;
	
	public Laptop() {
		System.out.println("Laptop Constructor called");
	}

	public Laptop(int modelNum, String brand, String ramsize, Processor processor) {
		super();
		this.modelNum = modelNum;
		this.brand = brand;
		this.ramsize = ramsize;
		this.processor = processor;
	}

	public int getModelNum() {
		return modelNum;
	}

	public void setModelNum(int modelNum) {
		this.modelNum = modelNum;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getRamsize() {
		return ramsize;
	}

	public void setRamsize(String ramsize) {
		this.ramsize = ramsize;
	}

	public Processor getProcessor() {
		return processor;
	}

	public void setProcessor(Processor processor) {
		this.processor = processor;
	}

	@Override
	public String toString() {
		return "Laptop [modelNum=" + modelNum + ", brand=" + brand + ", ramsize=" + ramsize + ", processor=" + processor
				+ ", hdd= "+hardDisk+"]";
	}

	@Override
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Destroy");
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("initailizing");
	}
	
//	@PostConstruct
//	public void init() {
//		System.out.println("initialization");
//	}
//	
//	@PreDestroy
//	public void destroy() {
//		System.out.println("Destroyed");
//	}
	

}
