package com.mphasis.training;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class I5Prcoessor implements Processor {
	
	public I5Prcoessor() {
		System.out.println("I5Prcoessor Called");
		
	}

	@Override
	public void process() {
		// TODO Auto-generated method stub

	}

}
