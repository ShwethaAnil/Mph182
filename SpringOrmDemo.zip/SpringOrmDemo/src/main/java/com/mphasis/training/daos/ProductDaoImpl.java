package com.mphasis.training.daos;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;
import com.mphasis.training.entities.Product;


@Repository
public class ProductDaoImpl implements ProductDao {
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public List<Product> retriveProducts() {
		Session session=sessionFactory.openSession();
		Criteria cr=session.createCriteria(Product.class);
		List<Product> products=cr.list();
		session.close();
		return products;
	}

	@Override
	public int addProduct(Product p) {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		int pid=(int) session.save(p);//insert
		session.getTransaction().commit();
		session.close();
		return pid;
	}

	@Override
	public int updateProduct(String pid, double cost, int qty) {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Product p = (Product) session.get(Product.class, pid);
		p.setCost(cost);
		p.setQty(qty);
		session.getTransaction().commit();
		session.close();
		return 0;
	}

	@Override
	public int deleteProduct(String pid) {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Product p = (Product) session.get(Product.class, pid);
		session.delete(p);
		session.getTransaction().commit();
		session.close();
		return 0;
	}

	@Override
	public Product retiveProductById(String pid){
		Session session=sessionFactory.openSession();
		Product p = (Product) session.get(Product.class, pid);
		session.close();
	return p;
	}
}
