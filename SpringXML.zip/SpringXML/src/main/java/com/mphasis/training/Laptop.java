package com.mphasis.training;

public class Laptop {
	
	private int modelNum;
	private String brand;
	private String  ramsize;
	private Processor processor;
	
	public Laptop() {
		System.out.println("Laptop Constructor called");
	}

	public Laptop(int modelNum, String brand, String ramsize, Processor processor) {
		super();
		this.modelNum = modelNum;
		this.brand = brand;
		this.ramsize = ramsize;
		this.processor = processor;
	}

	public int getModelNum() {
		return modelNum;
	}

	public void setModelNum(int modelNum) {
		this.modelNum = modelNum;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getRamsize() {
		return ramsize;
	}

	public void setRamsize(String ramsize) {
		this.ramsize = ramsize;
	}

	public Processor getProcessor() {
		return processor;
	}

//	public void setProcessor(Processor processor) {
//		this.processor = processor;
//	}

	@Override
	public String toString() {
		return "Laptop [modelNum=" + modelNum + ", brand=" + brand + ", ramsize=" + ramsize + ", processor=" + processor
				+ "]";
	}
	
	public void init() {
		System.out.println("initialization");
	}
	
	
	public void destroy() {
		System.out.println("Destroyed");
	}
	

}
