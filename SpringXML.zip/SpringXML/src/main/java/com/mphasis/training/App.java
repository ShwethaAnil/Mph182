package com.mphasis.training;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context=new ClassPathXmlApplicationContext("application.xml");
    	//BeanFactory factory = new XmlBeanFactory(new ClassPathResource("application.xml"));
    	//factory.getBean("l1");
//        
        Laptop l1=(Laptop) context.getBean("l1");
//        l1.setModelNum(323);
//        l1.setBrand("MAc");
//        l1.setProcessor((Processor) context.getBean("ip"));
//        l1.setRamsize("8 GB");
        System.out.println(l1);
        
        Laptop lp=(Laptop) context.getBean("l2");
        System.out.println(lp);
//        
//        
//        System.out.println(l1);
//        
//        Laptop l2=(Laptop) context.getBean("l1");
//        l2.setModelNum(324);
//        l2.setBrand("HP");
//        l2.setProcessor("snapDragon");
//        l2.setRamsize("8 GB");
//        
//        System.out.println(l2);
//        System.out.println(l1);
        
    }
}
