package com.mphasis.training;

public class I5Prcoessor implements Processor {
	
	public I5Prcoessor() {
		System.out.println("I5Prcoessor Called");
		
	}

	@Override
	public void process() {
		// TODO Auto-generated method stub

	}

}
