package com.mphasis.training.pl;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.mphasis.training.bos.ProductBo;
import com.mphasis.training.bos.ProductBoImpl;
import com.mphasis.training.exceptions.BuisnessException;
import com.mphasis.training.pojos.Product;
import com.mphasis.training.util.DbUtil;

public class ProductApp {

	public static void main(String[] args) {
		System.out.println("Welcome to Product App");
		Scanner sc=new Scanner(System.in);
		ProductBo productBo=new ProductBoImpl();
		do {
			System.out.println("1. Add Product \n 2. Retrive Product by index \n 3. Retive all Products \n "
					+ "4. Find the quality of a Product \n  \n 5. Update the Product \n"
					+ "6. Remove a product \n 7. Sort the product \n 8. Exit");
			switch(sc.nextInt()) {
			case 1:
				    System.out.println("Enter the Product details 1. pid, 2.pname 3.qty 4.cost 5.ratings");
			        Product p =new Product(sc.next(), sc.next(), sc.nextInt(), sc.nextDouble(), sc.nextDouble());
				try {
					productBo.addProduct(p);
					System.out.println("Product added to the list");
				} catch (BuisnessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				    break;
			case 2: System.out.println("Enter the prodcutid : P123");
				try {
					Product product= productBo.getProductById(sc.next());
					System.out.println(product);
				}catch(BuisnessException |SQLException e) {
					System.out.println(e.getMessage());
	
				}
					break;
			case 3:System.out.println("List of products");
				List<Product> prods;
				try {
					prods = productBo.getProducts();
					prods.forEach(pn-> System.out.println(pn));
				} catch (BuisnessException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
					
				break;
			case 4: System.out.println("Enter the pid which you want to know the quality");
					String pid=sc.next();
				Product p2;
				try {
					p2 = productBo.getProductById(pid);
					String quality = productBo.getQualityOfProduct(pid);
				    System.out.println("Product name"+p2.getPname()+"  Quality of a product " +quality);
				} catch (BuisnessException | NullPointerException |SQLException e) {
					e.printStackTrace();
				} 
			      break;
			case 5: System.out.println("Enter the pid which you want to update  cost and qty");
				try {
					productBo.editProduct(sc.next(), sc.nextDouble(), sc.nextInt());
					System.out.println("Product updated");
				} catch (BuisnessException e) {
					System.out.println(e.getMessage());
				}
			break;
			case 6: System.out.println("Enter pid which you want to delete");
				try {
					productBo.removeProduct(sc.next());
					System.out.println("Product Deleted");
				} catch (BuisnessException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 7: System.out.println("a. Sort By Name \n b.Soty By Cost \n c.Sort By Qty \n d.Sort By Rating");
			       char choice=sc.next().charAt(0);
			       List<Product> products=null;
			        if(choice == 'a') {
			        	products= productBo.sortByPname();
			        }else if( choice == 'b') {
			        	products= productBo.sortByCost();
			        }else if(choice == 'c') {
			        	products = productBo.sortByQty();
			        }else if(choice == 'd') {
			        	products = productBo.sortByRatings();
			        }else {
			        	System.out.println("Invalid Options");
			        }
			     //   products.forEach(pi-> System.out.println(pi));
			        products.forEach(System.out::println);
				break;
			case 8: System.out.println("Thank you");
			        sc.close();
			        DbUtil.closeConnection();
			        System.exit(0);
			 default: System.out.println("Invalid choice");       
			}
			
		}while(true);

	}

}
