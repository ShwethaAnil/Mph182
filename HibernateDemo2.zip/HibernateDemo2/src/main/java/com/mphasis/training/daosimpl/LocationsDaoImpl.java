package com.mphasis.training.daosimpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.mphasis.training.daos.LocationsDao;
import com.mphasis.training.entites.Jobs;
import com.mphasis.training.entites.Locations;
import com.mphasis.training.util.HibernateUtil;

public class LocationsDaoImpl implements LocationsDao {

SessionFactory sessionFactory;
	
	public LocationsDaoImpl() {
		sessionFactory = HibernateUtil.getSessionFactory();
	}

	@Override
	public Locations retirveLocationsById(int lid) {
		Session session=sessionFactory.openSession();
		Locations e=(Locations) session.get(Locations.class,lid);
		session.close();
		return e;
	}

}
