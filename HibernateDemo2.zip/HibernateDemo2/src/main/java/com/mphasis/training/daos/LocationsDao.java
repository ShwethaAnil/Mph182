package com.mphasis.training.daos;


import com.mphasis.training.entites.Locations;

public interface LocationsDao {
	public Locations retirveLocationsById(int lid);
}
