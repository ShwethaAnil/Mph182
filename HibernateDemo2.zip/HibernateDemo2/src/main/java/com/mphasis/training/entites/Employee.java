package com.mphasis.training.entites;


import javax.persistence.CascadeType;

//import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Employee {

	@Id
	private int empid;
	@Column(length = 20)
	private String ename;
	@Column(precision = 10, scale= 2)
	private double salary;
	private String doj;
	private int bonus;
	@ManyToOne
	@JoinColumn(name="jcode")
	private Jobs jcode=new Jobs();
	@ManyToOne
	@JoinColumn(name="deptno")
	private Department dept=new Department();
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="mgrno")
	private Employee emp;
	
	
	public Employee() {
		
	}


	public Employee(int empid, String ename, double salary, String doj, int bonus) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.salary = salary;
		this.doj = doj;
		this.bonus = bonus;
	}


	public int getEmpid() {
		return empid;
	}


	public void setEmpid(int empid) {
		this.empid = empid;
	}


	public String getEname() {
		return ename;
	}


	public void setEname(String ename) {
		this.ename = ename;
	}


	public double getSalary() {
		return salary;
	}


	public void setSalary(double salary) {
		this.salary = salary;
	}


	public String getDoj() {
		return doj;
	}


	public void setDoj(String doj) {
		this.doj = doj;
	}


	public int getBonus() {
		return bonus;
	}


	public void setBonus(int bonus) {
		this.bonus = bonus;
	}


	public Jobs getJcode() {
		return jcode;
	}


	public void setJcode(Jobs jcode) {
		this.jcode = jcode;
	}


	public Department getDept() {
		return dept;
	}


	public void setDept(Department dept) {
		this.dept = dept;
	}


	public Employee getEmp() {
		return emp;
	}


	public void setEmp(Employee emp) {
		this.emp = emp;
	}


	public Employee(int empid, String ename, double salary, String doj, int bonus, Jobs jcode, Department dept,
			Employee emp) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.salary = salary;
		this.doj = doj;
		this.bonus = bonus;
		this.jcode = jcode;
		this.dept = dept;
		this.emp = emp;
	}


	@Override
	public String toString() {
		return " [empid=" + empid + "\n ename=" + ename + "\n salary=" + salary + "\n doj=" + doj + "\n bonus="
				+ bonus + "\n jcode=" + jcode + "\n dept=" + dept +"]";
	}
	
	
}
