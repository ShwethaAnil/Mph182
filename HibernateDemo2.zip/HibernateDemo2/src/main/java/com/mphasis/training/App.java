package com.mphasis.training;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.mphasis.training.entites.Course;
import com.mphasis.training.entites.Student;




/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
        System.out.println("Started");
        Configuration con=new Configuration().configure().addAnnotatedClass(Course.class).addAnnotatedClass(Student.class);
        StandardServiceRegistryBuilder reg=new StandardServiceRegistryBuilder().applySettings(con.getProperties());
        SessionFactory sf=con.buildSessionFactory(reg.build());
        Session session=sf.openSession();
//        Course c1=new Course("Sql", "Sudarshan");
//        Course c2=new Course("Mongo", "Vinutha");
//        
//        Student s1=new Student();
//        s1.setStid(113);
//        s1.setStname("Chandan");
//        s1.setAddress("Kadapa");
//        s1.getCourses().add(c1);
//        
//        
//        Student s2=new Student();
//        s2.setStid(114);
//        s2.setStname("Nida");
//        s2.setAddress("Gwalior");
//      //  s2.getCourses().add(c1);
//        s2.getCourses().add(c2);
        
        session.beginTransaction();
       // session.save(c1);
        //session.save(c2);
        //session.save(s1);
        //session.save(s2);
        
//        Course c1=(Course) session.get(Course.class, 1);
//        session.delete(c1);
        session.getTransaction().commit();
        
        //Student s1=(Student) session.get(Student.class, 111);
        //Student s2=(Student) session.get(Student.class, 111);
        
        Course c1=(Course) session.get(Course.class, 1);
        System.out.println(c1);
//        Course c3=(Course) session.get(Course.class, 2);
//        System.out.println(c3);
//        Course c4=(Course) session.get(Course.class, 2);
//        System.out.println(c4);
//       
       
//        System.out.println(s1);
        
       session.close();
       
       
       Session s2=sf.openSession();
       	Course c7=(Course)s2.get(Course.class, 1);
       	
       s2.close();
       
       
       sf.close();
       
       System.out.println("done");

    }
}
