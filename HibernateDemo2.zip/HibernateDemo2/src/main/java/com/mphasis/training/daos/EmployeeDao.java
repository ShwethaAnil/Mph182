package com.mphasis.training.daos;

import java.util.List;
import com.mphasis.training.entites.Employee;


public interface EmployeeDao {
	
	public void insertEmployee(Employee e);
	public void updateEmployee(Employee e);
	public void deleteEmployeeById(int eid);
	public Employee retriveEmployeeById(int eid);
	public List<Employee> retriveAll();
	public List<Employee> retirveEmpByJob(String jname);
	public List<Employee> retriveEmpByDepartment(String dname);
	public List<Employee> retriveEmpByLocation(String lname);
	public List<Employee> retriveEmpByJobAndLocation(String jname, String lname);
	public List<Employee> retriveEmpByDoj(String doj);
	public List<Employee> retriveEmpByDojOrSalary(String doj, double salary);
	public List<Employee> retriveEmpByDojAndSalary(String doj, double salary);
	public List<Employee> retriveEmployeeOrderByDoj();
	
	

}
