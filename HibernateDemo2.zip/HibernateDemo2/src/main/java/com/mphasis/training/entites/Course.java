package com.mphasis.training.entites;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class Course {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cid;
	@Column(length = 25)
	private String cname;
	private String trainer;
	
	@ManyToMany(mappedBy = "courses")
	private List<Student> students=new ArrayList<Student>();
	
	public Course() {
		
	}
	public Course (String cname, String trainer) {
	
		this.cname = cname;
		this.trainer = trainer;
	}
	
	public Course(int cid, String cname, String trainer) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.trainer = trainer;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getTrainer() {
		return trainer;
	}
	public void setTrainer(String trainer) {
		this.trainer = trainer;
	}
	@Override
	public String toString() {
		return "Course [cid=" + cid + ", cname=" + cname + ", trainer=" + trainer + "]";
	}
	
	
}
