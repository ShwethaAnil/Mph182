package com.mphasis.training.daos;


import com.mphasis.training.entites.Jobs;

public interface JobsDao {
	public Jobs retirveJobById(String jid);
}
