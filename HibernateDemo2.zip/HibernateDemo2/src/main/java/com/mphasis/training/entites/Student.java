package com.mphasis.training.entites;

import java.util.ArrayList;

import java.util.List;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;


@Entity
public class Student {
	@Id
	private int stid;
	private String stname;
	private String address;
	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<Course> courses=new ArrayList<>();
	
	
//	@Transient
//	private int marks;
	public Student() {
		
	}

	public Student(int stid, String stname, String address, List<Course> courses) {
		super();
		this.stid = stid;
		this.stname = stname;
		this.address = address;
		this.courses = courses;
	}

	public int getStid() {
		return stid;
	}

	public void setStid(int stid) {
		this.stid = stid;
	}

	public String getStname() {
		return stname;
	}

	public void setStname(String stname) {
		this.stname = stname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public List<Course> getCourses() {
		return courses;
	}

	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}

	@Override
	public String toString() {
		return "Student [stid=" + stid + ", stname=" + stname + ", address=" + address + ", courses=" + courses + "]";
	}
	
	
	

}
