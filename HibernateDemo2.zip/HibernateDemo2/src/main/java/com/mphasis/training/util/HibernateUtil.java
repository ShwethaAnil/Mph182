package com.mphasis.training.util;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.mphasis.training.entites.*;


public class HibernateUtil {
	
	private static  SessionFactory sessionFactory=null;
	
	public static  SessionFactory getSessionFactory() {
		 Configuration con=new Configuration().configure()
				 .addAnnotatedClass(Jobs.class)
				 .addAnnotatedClass(Locations.class)
				 .addAnnotatedClass(Department.class)
				 .addAnnotatedClass(Employee.class);
	        StandardServiceRegistryBuilder reg=new StandardServiceRegistryBuilder().applySettings(con.getProperties());
	        sessionFactory=con.buildSessionFactory(reg.build());
	        return sessionFactory;
	}
	
	public static void closeSessionFactory() {
		sessionFactory.close();
	}

}
