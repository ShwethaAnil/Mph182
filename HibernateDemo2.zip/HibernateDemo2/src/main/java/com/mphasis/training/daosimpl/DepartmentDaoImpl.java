package com.mphasis.training.daosimpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.mphasis.training.daos.DepartmentDao;
import com.mphasis.training.entites.Department;
import com.mphasis.training.entites.Employee;
import com.mphasis.training.util.HibernateUtil;

public class DepartmentDaoImpl implements DepartmentDao {

SessionFactory sessionFactory;
	
	public DepartmentDaoImpl() {
		sessionFactory = HibernateUtil.getSessionFactory();
	}

	@Override
	public Department retirveDepartmentById(int did) {
		Session session=sessionFactory.openSession();
		Department e=(Department) session.get(Department.class,did);
		session.close();
		return e;
	}

}
