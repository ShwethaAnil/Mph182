package com.mphasis.training.daosimpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.mphasis.training.daos.JobsDao;
import com.mphasis.training.entites.Department;
import com.mphasis.training.entites.Jobs;
import com.mphasis.training.util.HibernateUtil;

public class JobsDaoImpl implements JobsDao {

SessionFactory sessionFactory;
	
	public JobsDaoImpl() {
		sessionFactory = HibernateUtil.getSessionFactory();
	}

	@Override
	public Jobs retirveJobById(String jid) {
		Session session=sessionFactory.openSession();
		Jobs e=(Jobs) session.get(Jobs.class,jid);
		session.close();
		return e;
	}

}
