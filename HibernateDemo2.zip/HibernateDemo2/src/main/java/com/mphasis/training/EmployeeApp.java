package com.mphasis.training;

import com.mphasis.training.daos.DepartmentDao;
import com.mphasis.training.daos.EmployeeDao;
import com.mphasis.training.daos.JobsDao;
import com.mphasis.training.daos.LocationsDao;
import com.mphasis.training.daosimpl.DepartmentDaoImpl;
import com.mphasis.training.daosimpl.EmployeeDaoImpl;
import com.mphasis.training.daosimpl.JobsDaoImpl;
import com.mphasis.training.daosimpl.LocationsDaoImpl;
import com.mphasis.training.entites.Department;
import com.mphasis.training.entites.Employee;
import com.mphasis.training.entites.Jobs;
import com.mphasis.training.entites.Locations;
import com.mphasis.training.util.HibernateUtil;

public class EmployeeApp {

	public static void main(String[] args) {
		
		EmployeeDao employeeDao=new EmployeeDaoImpl();
		JobsDao jobsDao=new JobsDaoImpl();
	//	LocationsDao locationsDao=new LocationsDaoImpl();
		DepartmentDao departmentDao=new DepartmentDaoImpl();
		
		
		
		Employee emp=new Employee(113, "Anjali", 245678, "2020-01-31", 3457);
		Jobs j=jobsDao.retirveJobById("J01");
		emp.setJcode(j);
		//Locations loc=locationsDao.retirveLocationsById(1);
		
		Department d=departmentDao.retirveDepartmentById(900);
		emp.setDept(d);
		System.out.println("Manager number");
		
		emp.setEmp(employeeDao.retriveEmployeeById(112));
		
		System.out.println("Employee Adding");
		employeeDao.insertEmployee(emp);
		System.out.println("Done");
		HibernateUtil.closeSessionFactory();
		

	}

}
