package com.mphasis.training.daosimpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.mphasis.training.daos.EmployeeDao;
import com.mphasis.training.entites.Department;
import com.mphasis.training.entites.Employee;
import com.mphasis.training.entites.Jobs;
import com.mphasis.training.entites.Locations;
import com.mphasis.training.util.HibernateUtil;

public class EmployeeDaoImpl implements EmployeeDao {
	
	SessionFactory sessionFactory;
	
	public EmployeeDaoImpl() {
		sessionFactory = HibernateUtil.getSessionFactory();
	}

	@Override
	public void insertEmployee(Employee e) {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.save(e);
		session.getTransaction().commit();
		session.close();
	}

	@Override
	public void updateEmployee(Employee e) {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.saveOrUpdate(e);
		session.getTransaction().commit();
		session.close();
	}

	@Override
	public void deleteEmployeeById(int eid) {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Employee e=(Employee) session.get(Employee.class,eid);
		session.delete(e);
		session.getTransaction().commit();
		session.close();

	}

	@Override
	public Employee retriveEmployeeById(int eid) {
		Session session=sessionFactory.openSession();
		Employee e=(Employee) session.get(Employee.class,eid);
		session.close();
		return e;
	}

	@Override
	public List<Employee> retriveAll() {
		Session session=sessionFactory.openSession();
		//Criterias
		Criteria cr=session.createCriteria(Employee.class);
		List<Employee> employees=cr.list();
		session.close();
		//HQL
//		Query query=session.createQuery("FROM Employee");
//		List<Employee> employees=query.list();
		//sql query
//		SQLQuery query1=session.createSQLQuery("select * from employee");
//		List<Employee> employees=query1.list();		
		return employees;
	}

	@Override
	public List<Employee> retirveEmpByJob(String jname) {
		//select * from employee where jcode = (select jcode from job where jname=?);
		Session session=sessionFactory.openSession();
			Criteria cr1=session.createCriteria(Jobs.class);
			cr1.add(Restrictions.eq("jname", jname));
			Jobs j=(Jobs) cr1.uniqueResult();
			
			Criteria cr=session.createCriteria(Employee.class);
			cr.add(Restrictions.eq("jcode", j));
			List<Employee> employees=cr.list();
		session.close();
		return employees;
	}

	@Override
	public List<Employee> retriveEmpByDepartment(String d) {
		Session session=sessionFactory.openSession();
		Criteria cr1=session.createCriteria(Department.class);
		cr1.add(Restrictions.eq("dname", d));
		Department dept=(Department) cr1.uniqueResult();
		
		Criteria cr=session.createCriteria(Employee.class);
		cr.add(Restrictions.eq("dept", dept));
		List<Employee> employees=cr.list();
	session.close();
	return employees;
	}

	@Override
	public List<Employee> retriveEmpByLocation(String l) {
			Session session=sessionFactory.openSession();
			Criteria cr=session.createCriteria(Locations.class);
			cr.add(Restrictions.eq("lname", l));
			Locations loc=(Locations) cr.uniqueResult();
			
			Criteria cr1=session.createCriteria(Department.class);
			cr1.add(Restrictions.eq("location", loc));
			List<Department> departments = cr.list();
			
			List<Employee> employees=new ArrayList<Employee>();
			for(Department d:departments) {
				Criteria cr2=session.createCriteria(Employee.class);
				cr2.add(Restrictions.eq("dept", d));
				employees.addAll(cr2.list());
			}
					
				session.close();	
		return employees;
	}

	@Override
	public List<Employee> retriveEmpByJobAndLocation(String jname, String lname) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> retriveEmpByDoj(String doj) {
		Session session=sessionFactory.openSession();
		Criteria cr=session.createCriteria(Employee.class);
		cr.add(Restrictions.eq("doj", doj));
		List<Employee> employees=cr.list();
		session.close();
		return employees;
	}

	@Override
	public List<Employee> retriveEmpByDojOrSalary(String doj, double salary) {
		Session session=sessionFactory.openSession();
		Criteria cr=session.createCriteria(Employee.class);
		Criterion cdoj=Restrictions.eq("doj", doj);
		Criterion csal=Restrictions.eq("salary", salary);
		LogicalExpression orExpr=Restrictions.or(cdoj, csal);
		cr.add(orExpr);
		List<Employee> employees=cr.list();
		session.close();
		return employees;

	}

	@Override
	public List<Employee> retriveEmpByDojAndSalary(String doj, double salary) {
		Session session=sessionFactory.openSession();
//		Criteria cr=session.createCriteria(Employee.class);
//		Criterion cdoj=Restrictions.eq("doj", doj);
//		Criterion csal=Restrictions.eq("salary", salary);
//		LogicalExpression andExpr=Restrictions.and(cdoj, csal);
//		cr.add(andExpr);
//		List<Employee> employees=cr.list();
//		session.close();
		Query query=session.createQuery("FROM Employee E where E.doj=:doj AND E.salary=:salary");
		query.setParameter("doj", doj);
		query.setParameter("salary", salary);
		List<Employee> employees=query.list();
		session.close();
		return employees;
	}

	@Override
	public List<Employee> retriveEmployeeOrderByDoj() {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
//		Criteria cr=session.createCriteria(Employee.class);
//		cr.addOrder(Order.asc("doj"));
//		List<Employee> employees=cr.list();
		
		Query query=session.createQuery("FROM Employee E ORDER BY E.doj DESC");
		List<Employee> employees=query.list();
		session.close();
		return employees;
		
	}
}
