package com.mphasis.training.daos;

import com.mphasis.training.entites.Department;

public interface DepartmentDao {
	
	public Department retirveDepartmentById(int did);

}
