package com.mphasis.training.exceptions;

import java.util.Date;

public class ExceptionResponse {
	private Date date;
	private String message;
	private String descripton;
	public ExceptionResponse(Date date, String message, String descripton) {
		super();
		this.date = date;
		this.message = message;
		this.descripton = descripton;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDescripton() {
		return descripton;
	}
	public void setDescripton(String descripton) {
		this.descripton = descripton;
	}
	
	
}
