package com.mphasis.training.bos;

import java.util.List;

import com.mphasis.training.entites.Employee;
import com.mphasis.training.exceptions.BuisnessException;
import com.mphasis.training.exceptions.RecordNotFoundException;

public interface EmployeeBo {
	
	public List<Employee> getAll()throws BuisnessException;
	public void addEmployee(Employee e)throws BuisnessException;
	public void updateEmployee(Employee e)throws BuisnessException;
	public void deleteEmployee(int eid)throws BuisnessException;
	public Employee getEmployeeById(int eid)throws RecordNotFoundException;
	public List<Employee> getBySalary(double salary);
	public List<Employee> getByGender(String gender);
	public List<Employee> getByGenderAndSalary(String gender,double salary);
	public List<Employee> getGreaterThanSalary(double salary);
	public List<Employee> getByGenderGreaterThanOrderBySalaryDesc(String gender);
}
