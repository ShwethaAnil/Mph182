package com.mphasis.training.entites;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int empid;
	private String ename;
	private String gender;
	private double salary;
	private String dob;
	
	public Employee() {
		
	}

	public Employee(int empid, String ename, String gender, double salary, String dob) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.gender = gender;
		this.salary = salary;
		this.dob = dob;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", ename=" + ename + ", gender=" + gender + ", salary=" + salary + ", dob="
				+ dob + "]";
	}
	
	
}
