package com.mphasis.training.bos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.training.daos.EmployeeRepository;
import com.mphasis.training.entites.Employee;
import com.mphasis.training.exceptions.BuisnessException;
import com.mphasis.training.exceptions.RecordNotFoundException;

@Service
public class EmployeeBoImpl implements EmployeeBo {
	
	@Autowired
	EmployeeRepository employeeRepository;

	@Override
	public List<Employee> getAll() throws BuisnessException {
		List<Employee> employees=(List<Employee>) employeeRepository.findAll();
		if(employees.isEmpty())
			throw new BuisnessException("No Employees present");
		return employees;
	}

	@Override
	public void addEmployee(Employee e) throws BuisnessException {
		// TODO Auto-generated method stub
		employeeRepository.save(e);
	}

	@Override
	public void updateEmployee(Employee e) throws BuisnessException {
		// TODO Auto-generated method stub
		employeeRepository.save(e);
	}

	@Override
	public void deleteEmployee(int eid) throws BuisnessException {
		// TODO Auto-generated method stub
		employeeRepository.deleteById(eid);
	}

	@Override
	public Employee getEmployeeById(int eid) throws RecordNotFoundException {
		// TODO Auto-generated method stub
		
		return employeeRepository.findById(eid).get();
	}

	@Override
	public List<Employee> getBySalary(double salary) {
		// TODO Auto-generated method stub
		return employeeRepository.findBySalary(salary);
	}

	@Override
	public List<Employee> getByGender(String gender) {
		// TODO Auto-generated method stub
		return employeeRepository.findByGender(gender);
	}

	@Override
	public List<Employee> getByGenderAndSalary(String gender, double salary) {
		// TODO Auto-generated method stub
		return employeeRepository.findByGenderAndSalary(gender, salary);
	}

	@Override
	public List<Employee> getGreaterThanSalary(double salary) {
		// TODO Auto-generated method stub
		return employeeRepository.findGreaterThanSalary(salary);
	}

	@Override
	public List<Employee> getByGenderGreaterThanOrderBySalaryDesc(String gender) {
		// TODO Auto-generated method stub
		return employeeRepository.findByGenderGreaterThanOrderBySalaryDesc(gender);
	}

}
