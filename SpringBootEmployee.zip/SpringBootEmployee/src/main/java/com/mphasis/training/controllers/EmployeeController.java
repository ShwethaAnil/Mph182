package com.mphasis.training.controllers;

import java.net.URI;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import com.mphasis.training.bos.EmployeeBo;
import com.mphasis.training.entites.Employee;
import com.mphasis.training.exceptions.BuisnessException;
import com.mphasis.training.exceptions.RecordNotFoundException;

@CrossOrigin(value="*")
@RestController
public class EmployeeController {

	
	@Autowired
	EmployeeBo employeeBo;
	
	@RequestMapping(value = "/emp", produces = MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.GET)
	public ResponseEntity<?> getEmployees() throws BuisnessException{
		return ResponseEntity.ok().body(employeeBo.getAll());
	}
	
	@RequestMapping(value = "/emp/{id}", produces = MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.GET)
	public ResponseEntity<?> getEmployee(@PathVariable("id")int id) throws RecordNotFoundException{
		return ResponseEntity.ok().body(employeeBo.getEmployeeById(id));
	}
	
	@RequestMapping(value = "/employee/{gender}", produces = MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.GET)
	public ResponseEntity<?> getEmployeeByGender(@PathVariable("gender")String gender) throws RecordNotFoundException{
		return ResponseEntity.ok().body(employeeBo.getByGender(gender));
	}
	
	@RequestMapping(value = "/employees/{salary}", produces = MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.GET)
	public ResponseEntity<?> getEmployeeBySalary(@PathVariable("salary")double salary) throws RecordNotFoundException{
		return ResponseEntity.ok().body(employeeBo.getBySalary(salary));
	}
	
	@RequestMapping(value = "/employees/{salary}/{gender}", produces = MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.GET)
	public ResponseEntity<?> getEmployeeBySalaryAndGender(@PathVariable("salary")double salary, @PathVariable("gender")String gender) throws RecordNotFoundException{
		return ResponseEntity.ok().body(employeeBo.getByGenderAndSalary(gender, salary));
	}
	
	@RequestMapping(value = "/emps/{gender}", produces = MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.GET)
	public ResponseEntity<?> getEmployeeGenderGreaterThanOrderBySalaryDesc(@PathVariable("gender")String gender) throws RecordNotFoundException{
		return ResponseEntity.ok().body(employeeBo.getByGenderGreaterThanOrderBySalaryDesc(gender));
	}
	
	@RequestMapping(value = "/empsal/{salary}", produces = MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.GET)
	public ResponseEntity<?> getEmployeeGenderGreaterThanOrderBySalaryDesc(@PathVariable("salary")double salary) throws RecordNotFoundException{
		return ResponseEntity.ok().body(employeeBo.getGreaterThanSalary(salary));
	}
	
	
	@RequestMapping(value = "/emp", produces = MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public ResponseEntity<?> addEmployeeByGender(@RequestBody Employee employee) throws BuisnessException{
		final URI location=MvcUriComponentsBuilder.fromController(
				getClass())
				.path("/emp/{id}")
				.buildAndExpand(employee.getEmpid())
				.toUri();
		employeeBo.addEmployee(employee);
		return ResponseEntity.created(location).body(employee);
	}
	
	@RequestMapping(value = "/emp", produces = MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE, 
			method=RequestMethod.PUT)
	public ResponseEntity<?> updateEmployeeByGender(@RequestBody Employee employee) throws BuisnessException{
		final URI location=MvcUriComponentsBuilder.fromController(
				getClass())
				.path("/emp/{id}")
				.buildAndExpand(employee.getEmpid())
				.toUri();
		employeeBo.updateEmployee(employee);
		return ResponseEntity.created(location).body(employee);
	}
	
	
	@RequestMapping(value="/{id}", produces = MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.DELETE)
	@ResponseBody
	public ResponseEntity<?> removeProduct(@PathVariable("id")int id) throws BuisnessException, SQLException{
		System.out.println("request coming");
		employeeBo.deleteEmployee(id);
		return ResponseEntity.ok().body("Removed");
	}
	
}
