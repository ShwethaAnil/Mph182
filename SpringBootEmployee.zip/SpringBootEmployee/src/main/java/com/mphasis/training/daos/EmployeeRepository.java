package com.mphasis.training.daos;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mphasis.training.entites.Employee;

@Repository
public interface EmployeeRepository extends CrudRepository<Employee, Integer> {

	
	public List<Employee> findBySalary(double salary);
	public List<Employee> findByGender(String gender);
	public List<Employee> findByGenderAndSalary(String gender,double salary);
	@Query(value = "select * from employee where salary>=:salary", nativeQuery = true)
	public List<Employee> findGreaterThanSalary(double salary);// findBySalaryGreaterThan  //findBySalaryGreaterThanEqual
	public List<Employee> findByGenderGreaterThanOrderBySalaryDesc(String gender);
	
	public List<Employee> findByEnameLike(String name);
}
