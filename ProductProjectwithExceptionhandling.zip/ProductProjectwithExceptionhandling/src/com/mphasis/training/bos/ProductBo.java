package com.mphasis.training.bos;

import com.mphasis.training.exceptions.BuisnessException;
import com.mphasis.training.pojos.Product;

public interface ProductBo {

	
		public Product[] getProducts();
		public Product getProductByIndex(int index)throws BuisnessException;
		public void addProduct(Product p,int index) throws BuisnessException;
		public String getQualityOfProduct(int index)throws BuisnessException;


}
