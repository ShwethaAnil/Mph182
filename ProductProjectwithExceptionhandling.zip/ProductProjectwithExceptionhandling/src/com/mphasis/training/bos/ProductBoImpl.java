package com.mphasis.training.bos;

import com.mphasis.training.exceptions.BuisnessException;
import com.mphasis.training.pojos.Product;

public class ProductBoImpl implements ProductBo {
	Product[] products = null;

	public ProductBoImpl() {
		products = new Product[5];
	}

	@Override
	public Product[] getProducts() {
		return products;
	}

	@Override
	public Product getProductByIndex(int index)throws BuisnessException {
		Product p = null;
		if (index < 5) {
			p = products[index];
		} else {
			throw new BuisnessException("Invalid index");
		}
		return p;
	}

	@Override
	public void addProduct(Product p, int index)throws BuisnessException {
		if (index < 5) {
			if (p.getPid().matches("[P][0-9]{3}")) {
				if (p.getPname().matches("[a-zA-Z]{3,15}")) {
					if (p.getQty() > 0) {
						if (p.getCost() > 0) {
							if(p.getRatings()<5 && p.getRatings()>0) {
								products[index] = p;
								//System.out.println("Product added at index "+index);
							}else {
								throw new BuisnessException("ratings with in 5");
							}	
						} else {
							throw new BuisnessException("cost accepts only postive number");
						}
					} else {
						throw new BuisnessException("qty accepts only positive number");
					}
				} else {
					throw new BuisnessException("Pname should contains only letters length 3 to 15");
				}
			} else {
				throw new BuisnessException("pid should start with P and 3 digits");
			}
		} else {
			throw new BuisnessException("only 5 indexs are allowed");
		}
	}

	@Override
	public String getQualityOfProduct(int index)throws BuisnessException {
		String quality=null;
		if(index< 5) {
			Product p=products[index];
			if(p.getRatings()>=4.5 && p.getRatings()<=5) {
				quality = "very good";
			}else if(p.getRatings()<4.5 && p.getRatings()>=4) {
				quality = "good";
			}else if(p.getRatings()<4 && p.getRatings()>3.5 ) {
				quality = "Ok Ok";
			}else if(p.getRatings()<=3.5 && p.getRatings()>2.5) {
				quality = "bad";
			}else if(p.getRatings() < 2.5) {
				quality ="very bad";
			}
			
		}else {
			throw new BuisnessException("only 5 indexs are allowed");
		}
		return quality;
	}

}
