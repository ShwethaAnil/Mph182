package com.mphasis.training.entites;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Laptop {

	@Id
	@Column(length = 10)
	private String lpcode;
	@Column(length = 10)
	private String brand;
	@Column(length = 10)
	private String processor;
	private int ramsize;
	private int hddsize;
}
