package com.mphasis.training;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.mphasis.training.entites.Department;
import com.mphasis.training.entites.Employee;
import com.mphasis.training.entites.Jobs;
import com.mphasis.training.entites.Locations;

public class EmployeeApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration con=new Configuration().configure()
													.addAnnotatedClass(Locations.class)
													.addAnnotatedClass(Department.class)
													.addAnnotatedClass(Jobs.class)
													.addAnnotatedClass(Employee.class);
        StandardServiceRegistryBuilder reg=new StandardServiceRegistryBuilder().applySettings(con.getProperties());
        SessionFactory sf=con.buildSessionFactory(reg.build());
        Session session=sf.openSession();
        List<Employee> employees= session.createCriteria(Employee.class).list();
        employees.forEach(System.out::print);
       session.close();
       sf.close();
       System.out.println("Done");
	}

}
