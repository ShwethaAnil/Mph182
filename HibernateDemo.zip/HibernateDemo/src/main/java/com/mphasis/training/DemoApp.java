package com.mphasis.training;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.mphasis.training.entites.Account;
import com.mphasis.training.entites.Address;
import com.mphasis.training.entites.CurrentAccount;
import com.mphasis.training.entites.Department;
import com.mphasis.training.entites.Laptop;
import com.mphasis.training.entites.Locations;
import com.mphasis.training.entites.MphEmployee;
import com.mphasis.training.entites.Passenger;
import com.mphasis.training.entites.SavingsAccount;
import com.mphasis.training.entites.Student;


public class DemoApp {
	
	public static void main(String args[]) {
		Configuration con=new Configuration().configure()
				.addAnnotatedClass(Passenger.class);
				//.addAnnotatedClass(CurrentAccount.class);
        StandardServiceRegistryBuilder reg=new StandardServiceRegistryBuilder().applySettings(con.getProperties());
        SessionFactory sf=con.buildSessionFactory(reg.build());
        Session session=sf.openSession();
        
        session.beginTransaction();
        
//        session.save(new Account(123,"Vinutha",34567890));
//        session.save(new CurrentAccount(124, "Karan", 234567845, "3456789"));
//        session.save(new SavingsAccount(125,"Sudarshan",5467890,45678));
        session.getTransaction().commit();

       session.close();
       sf.close();
       System.out.println("Done");
	}

}
