package com.mphasis.training.entites;

import java.time.LocalDate;

import java.util.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

@Entity
public class MphEmployee {

	@Id
	private int empid;
	private String ename;
	private double salary;
	private LocalDate doj;
	
	@OneToMany(mappedBy = "mpheMployee")
//	@JoinTable(name="emp_addr", joinColumns = {@JoinColumn(name="emp_id",referencedColumnName = "empid")},
//				inverseJoinColumns = {@JoinColumn(name="addr_id", referencedColumnName = "addid")})
	private List<Address> address=new ArrayList<>();
	
	
}
