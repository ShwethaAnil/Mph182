package com.mphasis.training.entites;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Passenger {
	
	@Id
	private int pid;
	
	private FullName fullname;
	
	private int numTickets;
	
	public Passenger() {
		
	}

	public Passenger(int pid, FullName fullname, int numTickets) {
		super();
		this.pid = pid;
		this.fullname = fullname;
		this.numTickets = numTickets;
	}
	
	

}
