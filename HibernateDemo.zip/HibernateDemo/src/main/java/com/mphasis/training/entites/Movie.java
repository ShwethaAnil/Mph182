package com.mphasis.training.entites;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table
public class Movie {
	@Id
	@Column(name="mid")
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int movieId;
	@Column(name = "mname", length = 15, nullable = false, unique = true)
	private String movieName;
	@Column(name = "mhero", length = 15)
	private String hero;
	@ElementCollection
	private List<String> heroine;
	@OneToMany(mappedBy = "movie")
	private List<Theater> theaters=new ArrayList<Theater>();
	
	public Movie() {
		
	}

	public Movie(int movieId, String movieName, String hero, List<String> heroine) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.hero = hero;
		this.heroine = heroine;
	}

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getHero() {
		return hero;
	}

	public void setHero(String hero) {
		this.hero = hero;
	}

	public List<String> getHeroine() {
		return heroine;
	}

	public void setHeroine(List<String> heroine) {
		this.heroine = heroine;
	}

	@Override
	public String toString() {
		return "[movieId=" + movieId + ", movieName=" + movieName + ", hero=" + hero + ", heroine=" + heroine
				+ "]";
	}
	

}
