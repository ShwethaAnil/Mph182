package com.mphasis.training.entites;

import javax.persistence.Embeddable;

@Embeddable
public class FullName {

	private String fname;
	private String lname;
	private String mname;
	
	public FullName() {
		
	}

	public FullName(String fname, String lname, String mname) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.mname = mname;
	}
	
}
