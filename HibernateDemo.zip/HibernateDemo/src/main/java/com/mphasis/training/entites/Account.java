package com.mphasis.training.entites;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
//@Inheritance(strategy = InheritanceType.JOINED)
//@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name="acc_type", discriminatorType = DiscriminatorType.STRING)
@DiscriminatorValue("acc")
//@PrimaryKeyJoinColumn(name="accountNum")
public class Account {
	
	@Id
	private int accountNum;
	@Column(length = 20)
	private String acc_holder_name;
	@Column(precision = 15, scale = 2)
	private double balance;
	
	public Account() {
		
	}

	public Account(int accountNum, String acc_holder_name, double balance) {
		super();
		this.accountNum = accountNum;
		this.acc_holder_name = acc_holder_name;
		this.balance = balance;
	}
	
	

}
