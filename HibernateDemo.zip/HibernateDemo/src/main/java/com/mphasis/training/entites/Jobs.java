package com.mphasis.training.entites;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Jobs implements Serializable {

	@Id
	@Column(name="JCODE", length = 5)
	private String jcode;
	@Column(name="JNAME", length = 30)
	private String jname;
	
	public Jobs() {
		
	}

	public Jobs(String jcode, String jname) {
		super();
		this.jcode = jcode;
		this.jname = jname;
	}

	public String getJcode() {
		return jcode;
	}

	public void setJcode(String jcode) {
		this.jcode = jcode;
	}

	public String getJname() {
		return jname;
	}

	public void setJname(String jname) {
		this.jname = jname;
	}

	@Override
	public String toString() {
		return "Jobs [jcode=" + jcode + ", jname=" + jname + "]";
	}
	
	
	
}
