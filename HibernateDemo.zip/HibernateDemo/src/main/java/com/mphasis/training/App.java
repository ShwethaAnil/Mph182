package com.mphasis.training;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;



import com.mphasis.training.entites.Movie;
import com.mphasis.training.entites.Theater;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	List<String> heroines =new ArrayList<>();
    	heroines.add("Vaishnavi");
    	heroines.add("Dakshyani");
    	heroines.add("Vinutha");
    		//{"Amulya","Nida","Swathi","Chandana"};
    	
        Movie m1=new Movie(0, "NSK", "Krishna", heroines);
        
        System.out.println("Started");
        Configuration con=new Configuration().configure().addAnnotatedClass(Movie.class).addAnnotatedClass(Theater.class);
        StandardServiceRegistryBuilder reg=new StandardServiceRegistryBuilder().applySettings(con.getProperties());
        SessionFactory sf=con.buildSessionFactory(reg.build());
        Session session=sf.openSession();
//       
//        session.beginTransaction();
//        session.save(m1);
//        session.save(new Theater(0, "Xyz"));
//       session.getTransaction().commit();
       session.close();
       sf.close();
       
       System.out.println("done");
        
//        session.beginTransaction();
//        //Movie m=(Movie) session.get(Movie.class, 125);
////        System.out.println(m);
////        m.setHeroine("Rashi");
////        System.out.println(m);
//        //session.delete(m);
//        //session.saveOrUpdate(m1);
//        
//    List<Movie> movies=   session.createCriteria(Movie.class).list();
//        movies.forEach(System.out::println);
//        
//        session.getTransaction().commit();
//        
//        session.close();
        System.out.println("done");
    }
}
