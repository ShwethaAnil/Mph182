package com.mphasis.training.entites;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("CA")
public class CurrentAccount extends Account {
	
	private String voternum;
	
	public CurrentAccount() {
		
	}

	public CurrentAccount(int accountNum, String acc_holder_name, double balance, String voternum) {
		super(accountNum, acc_holder_name, balance);
		this.voternum=voternum;
		// TODO Auto-generated constructor stub
	}
	
	

}
