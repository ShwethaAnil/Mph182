package com.mphasis.training.entites;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("SA")
public class SavingsAccount extends Account {
	
	private long adarNum;
	
	public SavingsAccount() {
		
	}

	public SavingsAccount(int accountNum, String acc_holder_name, double balance, long adarNum) {
		super(accountNum, acc_holder_name, balance);
		this.adarNum=adarNum;
		// TODO Auto-generated constructor stub
	}
	

}
