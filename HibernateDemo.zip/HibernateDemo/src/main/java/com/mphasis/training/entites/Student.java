package com.mphasis.training.entites;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "stu_seq")
	@SequenceGenerator(sequenceName = "student_seq", 
	allocationSize = 1, initialValue = 100, name="stu_seq")
	private int stid;
	@Column(length = 10)
	private String stname;
	private int age;
	private int marks;
	
	@OneToOne
	@JoinColumn(name="lpcode")
	private Laptop laptop=new Laptop();
	
	
}
