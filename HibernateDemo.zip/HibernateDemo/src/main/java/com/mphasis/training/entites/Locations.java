package com.mphasis.training.entites;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Locations implements Serializable {

	@Id
	private int lcode;
	@Column(length = 20)
	private String lname;
	
	public Locations() {
		
	}

	public Locations(int lcode, String lname) {
		super();
		this.lcode = lcode;
		this.lname = lname;
	}

	public int getLcode() {
		return lcode;
	}

	public void setLcode(int lcode) {
		this.lcode = lcode;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	@Override
	public String toString() {
		return "Locations [lcode=" + lcode + ", lname=" + lname + "]";
	}
	
	
}
