package com.mphasis.training.entites;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Theater {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int tid;
	private String tname;
	
	@ManyToOne
	private Movie movie=new Movie();
	
	public Theater() {
		
	}

	public Theater(int tid, String tname) {
		super();
		this.tid = tid;
		this.tname = tname;
	}
	
	

}
