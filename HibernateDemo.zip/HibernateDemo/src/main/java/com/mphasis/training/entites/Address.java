package com.mphasis.training.entites;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity(name="mphaddress")
public class Address {
	
	@Id
	private int addid;
	private String street;
	private String city;
	private String lane;
	private String state;
	private int pincode;
	private String addressType;
	
	
	@ManyToOne
	@JoinColumn(name="empid")
	private MphEmployee mpheMployee=new MphEmployee();
	

}
