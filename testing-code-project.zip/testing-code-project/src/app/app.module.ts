import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppComponent } from "./app.component";
import { HttpClientModule } from "@angular/common/http";
import { FormsModule } from "@angular/forms";
import { VoteComponent } from "./03-setup-and-teardown/vote.component";
import { TodoFormComponent } from "./04-forms/todo-form.component";
import { TodosComponent } from "./06-services/todos.component";
import { TodoService } from "./06-services/todo.service";
import { CounterComponent } from './counter/counter.component';
import { ProductlistComponent } from './productlist/productlist.component';

@NgModule({
  declarations: [
    AppComponent,
    VoteComponent,
    TodoFormComponent,
    TodosComponent,
    CounterComponent,
    ProductlistComponent,
  ],
  imports: [BrowserModule, HttpClientModule, FormsModule],
  providers: [TodoService],
  bootstrap: [AppComponent],
})
export class AppModule {}
