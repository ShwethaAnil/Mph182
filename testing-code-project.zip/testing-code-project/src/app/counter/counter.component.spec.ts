import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { CounterComponent } from "./counter.component";

describe("CounterComponent", () => {
  let component: CounterComponent;
  let fixture: ComponentFixture<CounterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CounterComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CounterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should decrement total votes when downvoted", () => {
    // Arrange

    // Act
    component.downVote();

    // Assert
    expect(component.totalVotes).toBe(-1);
  });

  it("should increment total votes when upvoted", () => {
    // Arrange

    // Act
    component.upVote();

    // Assert
    expect(component.totalVotes).toBe(1);
  });
});
