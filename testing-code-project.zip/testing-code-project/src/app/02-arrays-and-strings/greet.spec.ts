import { greet } from "./greet";
describe("greet", () => {
  it("should return the name in the message", () => {
    const result = greet("Shwetha");
    expect(result).toContain("Shwetha");
  });
});
