import { VoteComponent } from "./vote.component";

describe("VoteComponent", () => {
  let component: VoteComponent;

  it("should increment total votes when upvoted", () => {
    // Arrange
    const count = new VoteComponent();
    // Act
    count.upVote();

    // Assert
    expect(count.totalVotes).toBe(1);
  });

  it("should decrement total votes when downvoted", () => {
    // Arrange
    const count = new VoteComponent();
    // Act
    count.downVote();

    // Assert
    expect(count.totalVotes).toBe(-1);
  });
});
