import { Component } from "@angular/core";

@Component({
  selector: "app-vote",
  template: `<h1>He</h1>`,
})
export class VoteComponent {
  totalVotes = 0;

  upVote() {
    this.totalVotes++;
  }

  downVote() {
    this.totalVotes--;
  }
}
