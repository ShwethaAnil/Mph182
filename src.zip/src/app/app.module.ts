
import { BrowserModule } from '@angular/platform-browser';
import { NgModule , CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { JobsComponent } from './jobs/jobs.component';
import { LocationsComponent } from './locations/locations.component';
import { DepartmentsComponent } from './departments/departments.component';
import { EmployeesComponent } from './employees/employees.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { PeopleService } from './people.service';
import { AddjobComponent } from './addjob/addjob.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AddlocationComponent } from './addlocation/addlocation.component';
import { AdddepartmentComponent } from './adddepartment/adddepartment.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';

@NgModule({
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    FormsModule,
    MatDialogModule
  ],
  declarations: [
    AppComponent,
    JobsComponent,
    LocationsComponent,
    DepartmentsComponent,
    EmployeesComponent,
    PagenotfoundComponent,
    AddjobComponent,
    AddlocationComponent,
    AdddepartmentComponent,
    AddemployeeComponent,
    LoginComponent,
    HeaderComponent,
    HomeComponent
  ],
  providers: [PeopleService],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  bootstrap: [AppComponent]
})
export class AppModule { }
