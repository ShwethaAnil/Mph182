import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { JobsComponent } from './jobs/jobs.component';
import { LocationsComponent } from './locations/locations.component';
import { DepartmentsComponent } from './departments/departments.component';
import { EmployeesComponent } from './employees/employees.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { AddjobComponent } from './addjob/addjob.component';
import { AddlocationComponent } from './addlocation/addlocation.component';
import { AdddepartmentComponent } from './adddepartment/adddepartment.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { LoginComponent } from './login/login.component';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';


const routes: Routes = [
  {path: 'login', component: LoginComponent},
  {path: 'home', component: HomeComponent,
  children : [
    {path: 'jobs', component: JobsComponent},
  {path: 'locations', component: LocationsComponent},
  {path: 'departments', component: DepartmentsComponent},
  {path: 'people', component: EmployeesComponent },
  {path: 'addJob', component: AddjobComponent},
  {path: 'addLocation', component: AddlocationComponent},
  {path: 'addDepartment', component: AdddepartmentComponent},
  {path: 'addPeople', component: AddemployeeComponent}
  ]},
  {path: '', redirectTo: '/login', pathMatch: 'full' },
  {path: '**', component: PagenotfoundComponent}
];

@NgModule({
  imports: [RouterModule, RouterModule.forRoot(routes, { onSameUrlNavigation : 'reload'})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
