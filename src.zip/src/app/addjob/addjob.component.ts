import { Component } from '@angular/core';
import { PeopleService } from '../people.service';
import { Router } from '@angular/router';
import { Job } from '../job';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-addjob',
  templateUrl: './addjob.component.html',
  styleUrls: ['./addjob.component.css']
})
export class AddjobComponent {

   job = new Job();
   errorStatus: string;
  constructor(private peopleService: PeopleService, private router: Router, private dialog: MatDialog ) { }

  addJob() {
    console.log('job called' + this.job);
    this.peopleService.addJob(this.job).subscribe(
      d => { this.router.navigate(['jobs']),
      this.dialog.closeAll();
    },
      error => this.errorStatus = error
    );
  }

  close() {
    this.dialog.closeAll();
  }
}
