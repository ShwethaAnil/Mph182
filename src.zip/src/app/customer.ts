export class Customer {
    cuid: number;
    cname: string;
    pass: string;
    email: string;
}
