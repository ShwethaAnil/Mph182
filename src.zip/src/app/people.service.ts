import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Job } from './job';
import { Location } from './location';
import { Department } from './department';
import { Employee } from './employee';
import { throwError } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class PeopleService {

  headers = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
};
  constructor(private httpClient: HttpClient) { }

  getJobs() {
    return this.httpClient.get<Job[]>('http://localhost:8089/SpringWithER/jobs')
          .pipe(catchError(this.errorHandler));
  }

  getLocations() {
    return this.httpClient.get<Location[]>('http://localhost.121:8089/SpringWithER/locations')
    .pipe(catchError(this.errorHandler));
  }

  getDepartments() {
    return this.httpClient.get<Department[]>('http://192.168.77.121:8089/SpringWithER/departments')
    .pipe(catchError(this.errorHandler));
  }

  getPeople() {
    return this.httpClient.get<Employee[]>('http://192.168.77.121:8089/SpringWithER/employees')
    .pipe(catchError(this.errorHandler));
  }

  getPeopleById(id: number) {
    return this.httpClient.get<Employee>('http://192.168.77.121:8089/SpringWithER/employee/' + id)
    .pipe(catchError(this.errorHandler));
  }

  addJob(job: Job) {
  return  this.httpClient.post('http://localhost:8089/SpringWithER/jobs',
     JSON.stringify(job), this.headers).
    pipe(catchError(this.errorHandler));
  }

  deleteJob(jcode: number) {
    return this.httpClient.delete(`http://192.168.77.121:8089/SpringWithER/jobs/${jcode}`)
    .pipe(catchError(this.errorHandler));
  }

  addEmployee(employee: Employee) {
    return  this.httpClient.post('http://localhost:8089/SpringWithER/employees',
    JSON.stringify(employee), this.headers).
   pipe(catchError(this.errorHandler));
  }

  updateEmployee(employee: Employee) {
    return  this.httpClient.put('http://192.168.77.121:8089/SpringWithER/employees',
    JSON.stringify(employee), this.headers).
   pipe(catchError(this.errorHandler));
  }

  deleteEmployee(eid: number) {
    return  this.httpClient.delete(`http://192.168.77.121:8089/SpringWithER/employees/${eid}`)
    .pipe(catchError(this.errorHandler));
  }



  errorHandler(error: HttpErrorResponse) {
    return throwError(error);
  }
}
