import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { Department } from '../department';
import { Job } from '../job';
import { PeopleService } from '../people.service';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material';


@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styles: []
})
export class AddemployeeComponent implements OnInit {
employee = new Employee();
departments: Department[];
jobs: Job[];
dcode: number;
jcode: number;
errorStatus: string;

  constructor(private peopleService: PeopleService, private router: Router,
              private dialog: MatDialog, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.peopleService.getDepartments().subscribe(d => this.departments = d);
    this.peopleService.getJobs().subscribe(d => this.jobs = d);
    this.employee.eid = +this.activatedRoute.snapshot.paramMap.get('eid');
    if (this.employee.eid !== 0) {
      this.peopleService.getPeopleById(this.employee.eid).subscribe(
        data => {
          this.employee = data;
          this.dcode = this.employee.dept.did;
          this.jcode = this.employee.job.jcode;
        }
      );
      // this.employee.ename = this.activatedRoute.snapshot.paramMap.get('ename');
      // this.employee.salary = +this.activatedRoute.snapshot.paramMap.get('salary');
      // this.employee.bonus = +this.activatedRoute.snapshot.paramMap.get('bonus');
    }
  }

  addPeople() {
    this.employee = {
      eid: this.employee.eid,
      ename: this.employee.ename,
      salary: this.employee.salary,
      doj: '',
      dept: {
        did: this.dcode,
        dname: 'prod',
        loc: {
          lid: 1,
          lname: 'Spring'
        }
      },
      job: {
        jcode: this.jcode,
        jname: 's'
      },
      bonus: this.employee.bonus
    };
    if (this.employee.eid === 0) {
    this.peopleService.addEmployee(this.employee).subscribe(
      d => this.router.navigateByUrl('people') ,
      e => this.errorStatus = e
    );
    } else {
      this.peopleService.updateEmployee(this.employee).subscribe(
        d => this.router.navigateByUrl('people') ,
        e => this.errorStatus = e
      );
    }

  }

  close() {
    this.dialog.closeAll();
  }
}
