import { Location } from './location';

export class Department {
    did: number;
    dname: string;
    loc: Location;
}
