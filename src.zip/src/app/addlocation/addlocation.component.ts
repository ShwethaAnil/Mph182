import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addlocation',
  templateUrl: './addlocation.component.html',
  styles: []
})
export class AddlocationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
