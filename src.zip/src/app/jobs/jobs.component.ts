import { Component, OnInit } from '@angular/core';
import { Job } from '../job';
import { PeopleService } from '../people.service';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { AddjobComponent } from '../addjob/addjob.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-jobs',
  templateUrl: './jobs.component.html',
  styleUrls: ['./jobs.component.css']
})
export class JobsComponent implements OnInit {
 jobs: Job[];
 errorStatus: string;
 closeResult: string;
  constructor(private peopleService: PeopleService, private router: Router, private dialog: MatDialog) { }

  ngOnInit() {
    this.peopleService.getJobs().subscribe(
      data => { this.jobs = data, console.log(data); },
      error => { this.errorStatus = error; }
    );
  }

  openForm() {
     this.dialog.open(AddjobComponent, {
      height: '400px',
      width: '600px',
    });
  }

  deleteJob(job: Job) {
    this.peopleService.deleteJob(job.jcode)
    .subscribe( d => this.router.navigate(['jobs']));
  }


}
