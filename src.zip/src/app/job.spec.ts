import { Job } from './job';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBed } from '@angular/core/testing';

beforeEach(() => TestBed.configureTestingModule({
  imports: [RouterTestingModule]
}));
describe('Job', () => {
  it('should create an instance', () => {
    expect(new Job()).toBeTruthy();
  });
});
