export class Location {
    lid: number;
    lname: string;
}
