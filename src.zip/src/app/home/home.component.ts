import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  template: `
  <div class="navbar navbar-expand-sm bg-dark navbar-dark">
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" routerLink="jobs">Job</a></li>
    <li class="nav-item ">
      <a class="nav-link" routerLink="locations">Location</a></li>
    <li class="nav-item ">
      <a  class="nav-link" routerLink="departments">Department</a></li>
    <li class="nav-item ">
      <a  class="nav-link" routerLink="people">People</a></li>
  </ul>
</div>
<br/>
<br/>
<router-outlet></router-outlet>
  `,
  styles: []
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
