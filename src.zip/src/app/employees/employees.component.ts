import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { PeopleService } from '../people.service';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { AddemployeeComponent } from '../addemployee/addemployee.component';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {
people: Employee[];
errorStatus: string;
  constructor(private peopleService: PeopleService, private router: Router,
              private matDialog: MatDialog) { }

  ngOnInit() {
    this.peopleService.getPeople().subscribe(
      people => this.people = people,
      e => this.errorStatus = e
    );
  }

  openform() {
    this.matDialog.open(AddemployeeComponent);
  }

  delete(emp: Employee) {
    this.peopleService.deleteEmployee(emp.eid).subscribe(
      e => this.router.navigate(['people'])
    );
  }

  edit(emp: Employee) {
    this.router.navigate(['addPeople', emp]);
  }
}
