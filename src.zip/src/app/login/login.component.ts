import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 cust = new Customer();
 status: string;
  constructor(private loginService: LoginService, private router: Router) { }

  ngOnInit() {
  }
  login() {
    this.loginService.login(this.cust.email, this.cust.pass).subscribe(
      d => {this.cust = d;
            if (this.cust.cuid > 0) {
                this.router.navigate(['home']);
        } else {
          this.status = 'invalid credentials';
        }
      },
      error => this.status = error
    );
  }

}
