export class Job {
    jcode: number;
    jname: string;
}
