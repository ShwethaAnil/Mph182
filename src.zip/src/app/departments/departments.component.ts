import { Component, OnInit } from '@angular/core';
import { Department } from '../department';
import { PeopleService } from '../people.service';

@Component({
  selector: 'app-departments',
  templateUrl: './departments.component.html',
  styleUrls: ['./departments.component.css']
})
export class DepartmentsComponent implements OnInit {
departments: Department[];
  constructor(private peopleService: PeopleService) { }

  ngOnInit() {
    this.peopleService.getDepartments().subscribe(
      ds => this.departments = ds
    );
  }

}
