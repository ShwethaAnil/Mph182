package com.mphasis.training.config;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class AspectHelper {
	
//	@Pointcut("execution(* com.mphasis.training.*.*.*(..))")
//	public void createPointcut() {
//		
//	}
	
	
//	@Before("execution(* com.mphasis.training.*.*.*(..))")
//	public void beforeMethod(JoinPoint jp) {
//		System.out.println("Before Called"+jp.getSignature().getName());
//	}
//	
//	@After("execution(* com.mphasis.training.bos.*.*(..))")
//	public void afterMethod(JoinPoint jp) {
//		System.out.println("After Bo Called" + jp.getSignature());
//	}
//	
//	@AfterReturning(value="execution(* com.mphasis.training.bos.*.*(..))", returning = "result")
//	public void afterReturningMethod(JoinPoint jp, Object result) {
//		System.out.println("After Bo Called" + jp.getSignature());
//		System.out.println("Result is "+result);
//	}
//	
//	@AfterThrowing(value="execution(* com.mphasis.training.bos.*.*(..))", throwing="ex")
//	public void afterThrowingMethod(JoinPoint jp, Exception ex)throws Throwable {
//		System.out.println("After Bo Called" + jp.getSignature()+" exception message"+ex.getMessage());
//	}

	private static Logger logger =Logger.getLogger(AspectHelper.class);
	
	@Around("execution(* com.mphasis.training.*.*.*(..))")
	public Object aroundMethod(ProceedingJoinPoint pjp) throws Throwable {
		logger.debug("Around Before Called" +pjp.getSignature().getName());
		//System.out.println();
		Object obj=pjp.proceed();
		logger.debug("Around After Called"+pjp.getSignature().getName());
		return obj;
	}
	
	
	
	
	
	
}
