package com.mphasis.training.daos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;
import com.mphasis.training.entities.Product;


@Repository
public class ProductDaoImpl implements ProductDao {
	
	@Autowired
	HibernateTemplate hibernateTemplate;

	@Override
	public List<Product> retriveProducts() {
		return (List<Product>) hibernateTemplate.find("FROM Product");
	}

	@Override
	public int addProduct(Product p) {
		hibernateTemplate.save(p);
		return 0;
	}

	@Override
	public int updateProduct(String pid, double cost, int qty) {
		Product p = (Product) hibernateTemplate.get(Product.class, pid);
		p.setCost(cost);
		p.setQty(qty);
		hibernateTemplate.update(p);
		return 0;
	}

	@Override
	public int deleteProduct(String pid) {
		Product p = (Product) hibernateTemplate.get(Product.class, pid);
		hibernateTemplate.delete(p);
		return 0;
	}

	@Override
	public Product retiveProductById(String pid){
		Product p = (Product) hibernateTemplate.get(Product.class, pid);	
		return p;
	}
}
