package com.mphasis.training.controllers;

import java.net.URI;
import java.sql.SQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import com.mphasis.training.bos.ProductBo;
import com.mphasis.training.entities.Product;
import com.mphasis.training.exceptions.BuisnessException;
import com.mphasis.training.exceptions.RecordNotFoundException;

@RestController
@RequestMapping("/admin")
public class ProductController {
	
	@Autowired
	private ProductBo productBo;

	@RequestMapping(value="/", produces = MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<?> getProducts() throws BuisnessException{
		return ResponseEntity.ok().body(productBo.getProducts());
	}
	
	
	
	@RequestMapping(value="/{id}", produces = MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<?> getProduct(@PathVariable("id")String id) throws RecordNotFoundException, SQLException{	
		return ResponseEntity.ok().body(productBo.getProductById(id));
	}
	

	@RequestMapping(value="/", produces = MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE, 
			method=RequestMethod.POST)
	public ResponseEntity<?> addProduct(@RequestBody Product p) throws BuisnessException{
		final URI location=MvcUriComponentsBuilder.fromController(
						getClass())
						.path("/{id}")
						.buildAndExpand(p.getPid())
						.toUri();
		productBo.addProduct(p);
		return ResponseEntity.created(location).body(p);
						
	}
	
	@RequestMapping(value="/{pid}/{cost}/{qty}", produces = MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE, 
			method=RequestMethod.PUT)
	public ResponseEntity<?> updateProduct(@PathVariable("pid")String pid, @PathVariable("cost")double cost,@PathVariable("qty")int qty) throws BuisnessException{
		productBo.editProduct(pid, cost, qty);
		return ResponseEntity.accepted().build();
						
	}
	
	@RequestMapping(value="/{id}", produces = MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.DELETE)
	@ResponseBody
	public ResponseEntity<?> removeProduct(@PathVariable("id")String id) throws BuisnessException, SQLException{
		productBo.removeProduct(id);
		return ResponseEntity.ok().body("Removed");
	}
}